$ErrorActionPreference = "Stop"

$docLocalPath = "c:\Users\yegam\OneDrive\Documents\Dissertation\Yagna_Spatio_Temporal_Crime_Hotspot\Yagna_Final_Dissertation.docx"
$backupPath = "c:\Users\yegam\OneDrive\Documents\Dissertation\Yagna_Spatio_Temporal_Crime_Hotspot\Yagna_Final_Dissertation_before_strict_layout_fix.docx"

function Clean-ParaText([string]$t) {
    if ($null -eq $t) { return "" }
    return (($t -replace "[`r`a]", "") -replace "\s+", " ").Trim()
}

function Get-Heading1Map($doc) {
    $map = @{}
    for ($i = 1; $i -le $doc.Paragraphs.Count; $i++) {
        $p = $doc.Paragraphs.Item($i)
        $styleName = $p.Range.Style.NameLocal
        $txt = Clean-ParaText $p.Range.Text
        if ($styleName -eq "Heading 1" -and $txt -ne "") {
            if (-not $map.ContainsKey($txt)) {
                $map[$txt] = $i
            }
        }
    }
    return $map
}

function Get-Heading2Map($doc) {
    $map = @{}
    for ($i = 1; $i -le $doc.Paragraphs.Count; $i++) {
        $p = $doc.Paragraphs.Item($i)
        $styleName = $p.Range.Style.NameLocal
        $txt = Clean-ParaText $p.Range.Text
        if ($styleName -eq "Heading 2" -and $txt -ne "") {
            if (-not $map.ContainsKey($txt)) {
                $map[$txt] = $i
            }
        }
    }
    return $map
}

function Get-NextHeading1Index($doc, [int]$index) {
    for ($i = $index + 1; $i -le $doc.Paragraphs.Count; $i++) {
        $p = $doc.Paragraphs.Item($i)
        if ($p.Range.Style.NameLocal -eq "Heading 1") {
            return $i
        }
    }
    return $null
}

function Move-HeadingBlockBefore($doc, [string]$headingToMove, [string]$targetHeading) {
    $h = Get-Heading1Map $doc
    if (-not $h.ContainsKey($headingToMove) -or -not $h.ContainsKey($targetHeading)) {
        return
    }

    $moveIdx = [int]$h[$headingToMove]
    $nextMove = Get-NextHeading1Index $doc $moveIdx
    $moveStart = $doc.Paragraphs.Item($moveIdx).Range.Start
    $moveEnd = if ($null -ne $nextMove) { $doc.Paragraphs.Item($nextMove).Range.Start } else { $doc.Content.End }

    $block = $doc.Range($moveStart, $moveEnd)
    $formatted = $block.FormattedText
    $block.Delete()

    $h2 = Get-Heading1Map $doc
    if (-not $h2.ContainsKey($targetHeading)) { return }
    $targetIdx = [int]$h2[$targetHeading]
    $targetStart = $doc.Paragraphs.Item($targetIdx).Range.Start
    $insertRange = $doc.Range($targetStart, $targetStart)
    $insertRange.FormattedText = $formatted
}

function Clear-SectionBodyByHeading($doc, [string]$headingText) {
    $h = Get-Heading1Map $doc
    if (-not $h.ContainsKey($headingText)) { return }
    $idx = [int]$h[$headingText]
    $nextIdx = Get-NextHeading1Index $doc $idx
    if ($null -eq $nextIdx) { return }
    $start = $doc.Paragraphs.Item($idx).Range.End
    $end = $doc.Paragraphs.Item($nextIdx).Range.Start
    if ($end -gt $start) {
        $doc.Range($start, $end).Delete()
    }
}

function Insert-TOC($doc, [string]$headingText) {
    $h = Get-Heading1Map $doc
    if (-not $h.ContainsKey($headingText)) { return }
    $idx = [int]$h[$headingText]
    $insertPos = $doc.Paragraphs.Item($idx).Range.End
    $rng = $doc.Range($insertPos, $insertPos)
    [void]$doc.TablesOfContents.Add($rng)
}

function Insert-TOF($doc, [string]$headingText, [string]$captionLabel) {
    $h = Get-Heading1Map $doc
    if (-not $h.ContainsKey($headingText)) { return }
    $idx = [int]$h[$headingText]
    $insertPos = $doc.Paragraphs.Item($idx).Range.End
    $rng = $doc.Range($insertPos, $insertPos)
    [void]$doc.TablesOfFigures.Add($rng, $captionLabel)
}

function Set-PageBreakBeforeHeading($doc, [string]$headingText, [bool]$value) {
    $h = Get-Heading1Map $doc
    if ($h.ContainsKey($headingText)) {
        $doc.Paragraphs.Item([int]$h[$headingText]).Format.PageBreakBefore = $value
    }
}

function Set-PageBreakBeforeHeading2($doc, [string]$headingText, [bool]$value) {
    $h = Get-Heading2Map $doc
    if ($h.ContainsKey($headingText)) {
        $doc.Paragraphs.Item([int]$h[$headingText]).Format.PageBreakBefore = $value
    }
}

try {
    $word = [Runtime.InteropServices.Marshal]::GetActiveObject("Word.Application")
} catch {
    $word = New-Object -ComObject Word.Application
}

$word.Visible = $true
$word.DisplayAlerts = 0

$doc = $null
foreach ($d in $word.Documents) {
    $full = ($d.FullName).ToString()
    if ($full -like "*Yagna_Final_Dissertation.docx") {
        $doc = $d
        break
    }
}
if ($null -eq $doc) {
    $doc = $word.Documents.Open($docLocalPath)
}

# Backup current local file state first (SaveCopyAs can fail for OneDrive URL-backed docs).
if (Test-Path $docLocalPath) {
    Copy-Item -Path $docLocalPath -Destination $backupPath -Force
}

# 1) Reorder front matter blocks to required sequence.
# Required: Title page, Contents, List of Figures, List of Tables + Acronyms, Abstract, Acknowledgements, Chapter 1...
Move-HeadingBlockBefore $doc "Contents" "Abstract"
Move-HeadingBlockBefore $doc "List of Figures" "List of Tables"
Move-HeadingBlockBefore $doc "Abstract" "Chapter 1 Introduction"
Move-HeadingBlockBefore $doc "Acknowledgements" "Chapter 1 Introduction"

# 2) Remove manual page breaks and reset page-break-before flags.
$findRange = $doc.Content
$find = $findRange.Find
$find.ClearFormatting()
$find.Replacement.ClearFormatting()
$find.Text = "^m"
$find.Replacement.Text = ""
$wdFindContinue = 1
$wdReplaceAll = 2
[void]$find.Execute($find.Text, $false, $false, $false, $false, $false, $true, $wdFindContinue, $false, $find.Replacement.Text, $wdReplaceAll)

for ($i = 1; $i -le $doc.Paragraphs.Count; $i++) {
    $doc.Paragraphs.Item($i).Format.PageBreakBefore = $false
}

# 3) Set style-level formatting rules.
$normal = $doc.Styles.Item("Normal")
$normal.Font.Name = "Times New Roman"
$normal.Font.Size = 12
$normal.ParagraphFormat.Alignment = 3   # Justify
$normal.ParagraphFormat.LineSpacingRule = 1  # 1.5
$normal.ParagraphFormat.SpaceBefore = 0
$normal.ParagraphFormat.SpaceAfter = 0

$caption = $doc.Styles.Item("Caption")
$caption.Font.Name = "Times New Roman"
$caption.Font.Bold = 0
$caption.ParagraphFormat.Alignment = 1  # Center
$caption.ParagraphFormat.LineSpacingRule = 1
$caption.ParagraphFormat.SpaceBefore = 0
$caption.ParagraphFormat.SpaceAfter = 0

foreach ($styleName in @("TOC 1", "TOC 2", "TOC 3", "TOC 4", "table of figures")) {
    try {
        $s = $doc.Styles.Item($styleName)
        $s.Font.Name = "Times New Roman"
        $s.Font.Size = 12
        $s.Font.Bold = 0
        $s.ParagraphFormat.Alignment = 3
        $s.ParagraphFormat.LineSpacingRule = 1
        $s.ParagraphFormat.SpaceBefore = 0
        $s.ParagraphFormat.SpaceAfter = 0
    } catch {
    }
}

# 4) Apply paragraph-level formatting (body justify, 1.5, single spacing between paragraphs).
for ($i = 1; $i -le $doc.Paragraphs.Count; $i++) {
    $p = $doc.Paragraphs.Item($i)
    $txt = Clean-ParaText $p.Range.Text
    $styleName = $p.Range.Style.NameLocal

    $p.Range.Font.Name = "Times New Roman"
    $p.Format.LineSpacingRule = 1
    $p.Format.SpaceBefore = 0
    $p.Format.SpaceAfter = 0

    if ($styleName -eq "Caption" -or $txt -match "^(Figure|Table)\s+\d") {
        $p.Range.Font.Bold = 0
        $p.Format.Alignment = 1  # center
    } elseif ($styleName -notlike "Heading*") {
        $p.Format.Alignment = 3  # justify
    }
}

# 5) Enforce front-matter/chapter page starts.
Set-PageBreakBeforeHeading $doc "Contents" $true               # page 2
Set-PageBreakBeforeHeading $doc "List of Figures" $true        # page 3
Set-PageBreakBeforeHeading $doc "List of Tables" $true         # page 4
Set-PageBreakBeforeHeading $doc "Abstract" $true               # page 5
Set-PageBreakBeforeHeading $doc "Acknowledgements" $true       # page 6

Set-PageBreakBeforeHeading2 $doc "1.1 Background" $false

foreach ($ch in @(
    "Chapter 1 Introduction",
    "Chapter 2 Literature Review and Related Work",
    "Chapter 3 Methodology",
    "Chapter 4 Experimental Results and Discussion",
    "Chapter 5 Discussion, Conclusion, and Future Work",
    "References"
)) {
    Set-PageBreakBeforeHeading $doc $ch $true
}

# Keep acronyms on same page as List of Tables.
Set-PageBreakBeforeHeading $doc "List of Acronyms" $false

# 6) Rebuild TOC / List of Figures / List of Tables with page numbers.
if ($doc.TablesOfContents.Count -gt 0) {
    for ($i = $doc.TablesOfContents.Count; $i -ge 1; $i--) {
        $doc.TablesOfContents.Item($i).Delete()
    }
}
if ($doc.TablesOfFigures.Count -gt 0) {
    for ($i = $doc.TablesOfFigures.Count; $i -ge 1; $i--) {
        $doc.TablesOfFigures.Item($i).Delete()
    }
}

Clear-SectionBodyByHeading $doc "Contents"
Clear-SectionBodyByHeading $doc "List of Figures"
Clear-SectionBodyByHeading $doc "List of Tables"

Insert-TOC $doc "Contents"
Insert-TOF $doc "List of Figures" "Figure"
Insert-TOF $doc "List of Tables" "Table"

# 7) Repaginate and update all fields so page numbers are accurate.
$doc.Repaginate()
$doc.Fields.Update() | Out-Null
if ($doc.TablesOfContents.Count -gt 0) {
    for ($i = 1; $i -le $doc.TablesOfContents.Count; $i++) { $doc.TablesOfContents.Item($i).Update() }
}
if ($doc.TablesOfFigures.Count -gt 0) {
    for ($i = 1; $i -le $doc.TablesOfFigures.Count; $i++) { $doc.TablesOfFigures.Item($i).Update() }
}

# 8) Save.
$doc.Save()

Write-Output "Strict layout formatting complete."
Write-Output "Edited document: $($doc.FullName)"
Write-Output "Backup: $backupPath"
