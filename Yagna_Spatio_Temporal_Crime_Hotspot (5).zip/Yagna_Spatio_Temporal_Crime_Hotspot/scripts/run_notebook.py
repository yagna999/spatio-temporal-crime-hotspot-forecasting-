﻿from pathlib import Path
import nbformat
from nbclient import NotebookClient

nb_path = Path('notebooks/realtime_crime_hotspot_pipeline.ipynb')
with nb_path.open('r', encoding='utf-8') as f:
    nb = nbformat.read(f, as_version=4)

client = NotebookClient(
    nb,
    timeout=1800,
    kernel_name='python3',
    resources={'metadata': {'path': str(nb_path.parent.resolve())}},
)
client.execute()

with nb_path.open('w', encoding='utf-8') as f:
    nbformat.write(nb, f)

print('Executed notebook:', nb_path)
