from __future__ import annotations

from pathlib import Path
import re
from collections import Counter

from docx import Document
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph


DOC_PATH = Path(
    r"c:\Users\yegam\OneDrive\Documents\Dissertation\Yagna_Spatio_Temporal_Crime_Hotspot\Yagna_Final_Dissertation.docx"
)


def insert_paragraph_after(paragraph: Paragraph, text: str, style: str = "Normal") -> Paragraph:
    new_p = OxmlElement("w:p")
    paragraph._p.addnext(new_p)
    new_para = Paragraph(new_p, paragraph._parent)
    new_para.style = style
    new_para.add_run(text)
    return new_para


def word_count_excluding_references(doc: Document) -> int:
    ref_idx = None
    for i, para in enumerate(doc.paragraphs):
        if para.style.name == "Heading 1" and para.text.strip().lower() == "references":
            ref_idx = i
            break
    if ref_idx is None:
        ref_idx = len(doc.paragraphs)
    text = "\n".join(p.text for p in doc.paragraphs[:ref_idx])
    return len(re.findall(r"\b[\w'-]+\b", text))


def duplicate_long_paragraphs(doc: Document) -> list[tuple[int, str]]:
    bucket: list[str] = []
    for p in doc.paragraphs:
        t = " ".join(p.text.split()).strip()
        if len(t) >= 120:
            bucket.append(t)
    c = Counter(bucket)
    return sorted([(n, t) for t, n in c.items() if n > 1], reverse=True)


CHAPTER_BLOCKS: dict[str, str] = {
    "Chapter 1 Introduction": (
        "Beyond the immediate project context, this introduction also positions the work within a broader methodological debate about what counts as strong evidence in applied "
        "predictive analytics. In many technical domains, performance reporting remains dominated by model-centric narratives in which architecture choice is treated as the "
        "primary explanatory variable. Public-safety analytics is less forgiving of that assumption because consequences are distributed across social settings, institutional "
        "processes, and human decision chains. A technically efficient model can still produce weak public value if it is difficult to interrogate, impossible to reproduce, "
        "or misaligned with operational tempo. Conversely, a model with only moderate marginal gains can be highly valuable when embedded in transparent procedures that improve "
        "collective judgement quality. This dissertation therefore adopts a systems view from the outset: evidence quality is evaluated through the interaction of data currency, "
        "representation design, threshold governance, and interpretive usability. This framing also clarifies what this study does not claim. It does not claim that statistical "
        "risk signals can replace local knowledge, and it does not claim that historical concentration patterns should be treated as normative targets for intervention. Rather, it "
        "argues that when risk modelling is framed as structured support for accountable human reasoning, it can reduce avoidable delay in recognising areas where preventive "
        "attention is likely to be most useful. The practical importance of that claim lies in institutional learning: teams can compare observed outcomes against documented model "
        "suggestions, refine strategy over time, and progressively improve both analytical discipline and operational coherence."
    ),
    "Chapter 2 Literature Review and Related Work": (
        "A second literature-level observation concerns reporting conventions themselves. Several studies provide strong predictive contributions but under-specify implementation "
        "choices that materially affect replicability, such as temporal window anchoring, class-threshold definitions, or post-training score handling. Without these details, it "
        "is difficult to judge whether measured gains are attributable to algorithmic structure, data leakage resistance, or favorable tuning artifacts. This issue has direct "
        "implications for dissertation quality: critical review should not only compare published metrics, but also compare methodological transparency. Another pattern in the "
        "literature is asymmetry between technical sophistication and operational interpretability. High-capacity models are frequently evaluated on aggregate metrics yet less "
        "often examined for explanation burden, calibration stability, or workflow fit under resource constraints. In practical settings, these factors determine whether a model "
        "is used consistently or gradually bypassed. The present study addresses that asymmetry by treating operational interpretability as a co-equal evaluation dimension rather "
        "than an optional add-on. In doing so, it aligns with a growing methodological argument in applied AI: robust evidence should include reproducibility pathways, error "
        "characterization, and explicit boundary conditions, not just comparative performance tables. This approach does not diminish algorithmic innovation; instead, it makes "
        "innovation legible and transferable across contexts where decision stakes are high and analytical claims require durable justification."
    ),
    "Chapter 3 Methodology": (
        "Methodological rigor in this study is reinforced by explicit handling of uncertainty propagation across stages. Retrieval uncertainty enters through source publication lag "
        "and potential month-level variation in reporting completeness. Representation uncertainty enters through grid discretization and feature construction choices. Model "
        "uncertainty enters through parameter estimation and threshold setting. Decision uncertainty enters through alert-policy interpretation and analyst response. Rather than "
        "collapsing these uncertainties into a single confidence number, the methodology keeps them distinguishable by preserving component outputs and metadata. This is important "
        "for two reasons. First, it allows targeted improvement: if performance drift occurs, the team can identify whether retrieval currency, feature relevance, or threshold "
        "policy is the likely source. Second, it supports accountable communication: users can understand that uncertainty is structured, not random, and can be managed through "
        "specific controls. The methodology also intentionally favors transparent heuristics where full probabilistic modeling is not feasible under project constraints. For "
        "example, weighted composite risk and quantile-based alert gates are simple enough to audit while still expressive enough to capture multiple risk dimensions. In high-"
        "stakes domains, this balance is often preferable to opaque optimization that maximizes short-term score gains at the expense of traceability. Overall, the chapter "
        "demonstrates that methodological quality is achieved not by complexity alone, but by coherence between assumptions, implementation, and evaluative claims."
    ),
    "Chapter 4 Experimental Results and Discussion": (
        "The discussion of results can be further strengthened by considering robustness under plausible counterfactual settings. If the decision threshold were reduced to increase "
        "recall, the likely consequence would be a larger candidate set with improved sensitivity but lower precision, potentially diluting analyst attention. If the threshold were "
        "raised, precision would likely increase while recall would fall, increasing the risk of missing emerging pressure points. This counterfactual framing illustrates why model "
        "evaluation in operational contexts must include policy-aware trade-off analysis. Another robustness dimension concerns temporal continuation. The current three-month test "
        "window provides a meaningful initial signal, but longer rolling windows would better expose season transitions, event-driven anomalies, and structural shifts in category "
        "mix. A third dimension is spatial heterogeneity. The current results show strong performance in a dense central zone; extension to mixed-density settings may alter feature "
        "utility and error balance. These considerations do not weaken the reported outcomes; they situate them in a realistic inferential frame and make clear what additional "
        "evidence would most efficiently increase confidence. In academic terms, this is an important distinction: strong dissertation practice does not require pretending the "
        "current experiment is final; it requires demonstrating that the experiment is sound, interpretable, and strategically informative for the next iteration."
    ),
    "Chapter 5 Discussion, Conclusion, and Future Work": (
        "The closing chapter also benefits from a governance-through-lifecycle perspective. Many analytical projects treat governance as a static checklist completed at deployment. "
        "In practice, governance is dynamic because model behavior, data context, and institutional incentives evolve over time. A technically well-governed system at launch can "
        "become poorly governed if recalibration, documentation, and accountability routines are not sustained. The study's proposed roadmap therefore emphasizes operating "
        "procedures as much as technical upgrades: regular threshold reviews, drift diagnostics, analyst feedback capture, and transparent reporting of overrides and edge cases. "
        "This lifecycle orientation has scholarly significance. It moves the contribution beyond a one-off forecasting exercise toward a replicable framework for responsible model "
        "maintenance in applied settings. The broader conclusion is that high academic standards in this domain are achieved when technical competence, evidential transparency, and "
        "institutional realism are treated as mutually reinforcing commitments. Under that standard, the dissertation provides a credible platform for continued research and measured "
        "practical extension, while remaining explicit about uncertainty, boundaries, and conditions for responsible use."
    ),
}


MARKER = "A second literature-level observation concerns reporting conventions themselves."


def main() -> None:
    if not DOC_PATH.exists():
        raise FileNotFoundError(f"Document not found: {DOC_PATH}")

    doc = Document(DOC_PATH)

    # Avoid accidental duplicate injection.
    joined = "\n".join(p.text for p in doc.paragraphs)
    if MARKER in joined:
        print("Chapter deepening blocks already present. No changes made.")
        print(f"Word count excluding references: {word_count_excluding_references(doc)}")
        return

    heading_lookup: dict[str, Paragraph] = {}
    for para in doc.paragraphs:
        if para.style.name == "Heading 1":
            t = para.text.strip()
            if t in CHAPTER_BLOCKS:
                heading_lookup[t] = para

    missing = [k for k in CHAPTER_BLOCKS if k not in heading_lookup]
    if missing:
        raise RuntimeError(f"Missing chapter headings: {missing}")

    for chapter_title, block in CHAPTER_BLOCKS.items():
        anchor = heading_lookup[chapter_title]
        insert_paragraph_after(anchor, block, style="Normal")

    # Safety cleanup for forbidden names.
    for para in doc.paragraphs:
        para.text = re.sub(r"\bYagna\b", "the study", para.text, flags=re.IGNORECASE)
        para.text = re.sub(r"\bKarthik\b", "the study", para.text, flags=re.IGNORECASE)

    doc.save(DOC_PATH)

    final_doc = Document(DOC_PATH)
    wc = word_count_excluding_references(final_doc)
    duplicates = duplicate_long_paragraphs(final_doc)
    print(f"Saved: {DOC_PATH}")
    print(f"Word count excluding references: {wc}")
    print(f"Repeated long paragraphs (>120 chars): {len(duplicates)}")
    for n, t in duplicates[:10]:
        print(f"COUNT={n} | {t[:180]}")


if __name__ == "__main__":
    main()

