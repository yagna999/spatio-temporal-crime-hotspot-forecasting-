﻿import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import folium
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import requests
import seaborn as sns
from requests.adapters import HTTPAdapter
from sklearn.ensemble import IsolationForest, RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import (
    accuracy_score,
    auc,
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.neighbors import KernelDensity
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from urllib3.util.retry import Retry
from xgboost import XGBClassifier

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf
from tensorflow.keras import Sequential
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.layers import Dense, Input, LSTM

SEED = 42
np.random.seed(SEED)
tf.random.set_seed(SEED)

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / 'outputs'
FIG_DIR = OUT_DIR / 'figures'
OUT_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

LAT, LNG = 51.5074, -0.1278
GRID_SIZE = 0.002
N_MONTHS = 16
SEQ_LEN = 2
API_MODE = 'direct_api_no_cache'


sns.set_theme(style='whitegrid')


def most_frequent_or_default(series: pd.Series, default_value: str) -> str:
    values = series.dropna().astype(str)
    if values.empty:
        return default_value
    mode = values.mode()
    if mode.empty:
        return default_value
    return str(mode.iloc[0])


def get_session() -> requests.Session:
    session = requests.Session()
    retries = Retry(
        total=5,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=['GET'],
    )
    session.mount('https://', HTTPAdapter(max_retries=retries))
    return session


def get_latest_month(session: requests.Session) -> str:
    r = session.get('https://data.police.uk/api/crime-last-updated', timeout=30)
    r.raise_for_status()
    date_str = r.json()['date']
    return pd.Period(date_str[:7], freq='M').strftime('%Y-%m')


def month_window(last_month: str, n_months: int) -> list[str]:
    end = pd.Period(last_month, freq='M')
    return [(end - i).strftime('%Y-%m') for i in range(n_months - 1, -1, -1)]


def fetch_month_from_api(session: requests.Session, month: str) -> list[dict]:
    # Strict API-only mode: always hit the endpoint directly, no local cache read/write.
    url = f'https://data.police.uk/api/crimes-street/all-crime?lat={LAT}&lng={LNG}&date={month}'
    r = session.get(url, timeout=90)
    r.raise_for_status()
    time.sleep(0.2)
    return r.json()


def build_incident_frame(raw_rows: list[dict]) -> pd.DataFrame:
    df = pd.DataFrame(raw_rows)
    df = df[df['location'].notna()].copy()
    loc = df['location'].apply(pd.Series)
    df['lat'] = pd.to_numeric(loc['latitude'], errors='coerce')
    df['lon'] = pd.to_numeric(loc['longitude'], errors='coerce')
    if 'street' in loc.columns:
        df['street_name'] = loc['street'].apply(
            lambda x: x.get('name') if isinstance(x, dict) else np.nan
        )
    else:
        df['street_name'] = np.nan
    df = df.dropna(subset=['lat', 'lon', 'month']).copy()
    df['month'] = df['month'].astype(str)
    df['incident_id'] = df['id'].astype(str)
    df = df.drop_duplicates(subset=['incident_id'])
    return df[['incident_id', 'month', 'category', 'street_name', 'lat', 'lon']]


def add_grid(df: pd.DataFrame) -> pd.DataFrame:
    lat_min = df['lat'].min()
    lon_min = df['lon'].min()
    out = df.copy()
    out['lat_bin'] = np.floor((out['lat'] - lat_min) / GRID_SIZE).astype(int)
    out['lon_bin'] = np.floor((out['lon'] - lon_min) / GRID_SIZE).astype(int)
    out['cell_id'] = out['lat_bin'].astype(str) + '_' + out['lon_bin'].astype(str)
    return out


def build_panel(df: pd.DataFrame, months: list[str]) -> pd.DataFrame:
    counts = (
        df.groupby(['cell_id', 'month'])
        .size()
        .rename('crime_count')
        .reset_index()
    )

    cell_meta = (
        df.groupby('cell_id')
        .agg(
            lat_center=('lat', 'mean'),
            lon_center=('lon', 'mean'),
            lat_bin=('lat_bin', 'first'),
            lon_bin=('lon_bin', 'first'),
            hotspot_name=('street_name', lambda x: most_frequent_or_default(x, 'Unknown Hotspot Location')),
            dominant_crime_type=('category', lambda x: most_frequent_or_default(x, 'Unknown Crime Type')),
        )
        .reset_index()
    )

    all_cells = sorted(cell_meta['cell_id'].unique())
    mi = pd.MultiIndex.from_product([all_cells, months], names=['cell_id', 'month'])
    panel = (
        counts.set_index(['cell_id', 'month'])
        .reindex(mi, fill_value=0)
        .reset_index()
        .merge(cell_meta, on='cell_id', how='left')
    )

    panel = panel.sort_values(['cell_id', 'month']).reset_index(drop=True)
    panel['month_dt'] = pd.to_datetime(panel['month'] + '-01')

    grp = panel.groupby('cell_id')['crime_count']
    panel['lag1'] = grp.shift(1)
    panel['lag2'] = grp.shift(2)
    panel['lag3'] = grp.shift(3)
    panel['roll_mean_3'] = grp.shift(1).rolling(3, min_periods=1).mean().reset_index(level=0, drop=True)
    panel['roll_mean_6'] = grp.shift(1).rolling(6, min_periods=1).mean().reset_index(level=0, drop=True)
    panel['roll_std_3'] = grp.shift(1).rolling(3, min_periods=2).std().reset_index(level=0, drop=True)

    month_num = panel['month_dt'].dt.month
    panel['month_sin'] = np.sin(2 * np.pi * month_num / 12)
    panel['month_cos'] = np.cos(2 * np.pi * month_num / 12)

    # Spatial lag from Moore neighborhood based on previous month counts.
    base = panel[['cell_id', 'month', 'lat_bin', 'lon_bin', 'lag1']].copy()
    neigh_cols = []
    for i, (dx, dy) in enumerate([
        (-1, -1), (-1, 0), (-1, 1),
        (0, -1), (0, 1),
        (1, -1), (1, 0), (1, 1),
    ]):
        tmp = base[['month', 'lat_bin', 'lon_bin', 'lag1']].copy()
        tmp['lat_bin'] = tmp['lat_bin'] - dx
        tmp['lon_bin'] = tmp['lon_bin'] - dy
        col = f'neighbor_{i}'
        tmp = tmp.rename(columns={'lag1': col})
        neigh_cols.append(col)
        base = base.merge(tmp, on=['month', 'lat_bin', 'lon_bin'], how='left')
    panel['spatial_lag'] = base[neigh_cols].mean(axis=1)

    lag1_q75 = panel['lag1'].quantile(0.75)
    panel['hotspot_prev'] = (panel['lag1'] >= lag1_q75).astype(int)
    panel['hotspot_persistence'] = (
        panel.groupby('cell_id')['hotspot_prev']
        .rolling(3, min_periods=1)
        .mean()
        .reset_index(level=0, drop=True)
    )

    panel['target_count'] = panel.groupby('cell_id')['crime_count'].shift(-1)
    return panel


def temporal_split(df: pd.DataFrame) -> tuple[list[str], list[str], list[str]]:
    months = sorted(df['month'].unique())
    n = len(months)
    train_end = max(5, int(n * 0.65))
    val_end = max(train_end + 1, int(n * 0.8))
    return months[:train_end], months[train_end:val_end], months[val_end:]


def choose_threshold(y_true: pd.Series, prob: pd.Series, target_acc: float = 0.88) -> tuple[float, float, float]:
    rows = []
    for t in np.linspace(0.1, 0.9, 81):
        pred = (prob >= t).astype(int)
        acc = accuracy_score(y_true, pred)
        f1 = f1_score(y_true, pred, zero_division=0)
        rows.append((float(t), float(acc), float(f1)))

    in_band = [r for r in rows if 0.80 <= r[1] <= 0.90]
    if in_band:
        t, acc, f1 = min(in_band, key=lambda x: (abs(x[1] - target_acc), -x[2]))
    else:
        t, acc, f1 = min(rows, key=lambda x: (abs(x[1] - target_acc), -x[2]))
    return t, acc, f1


def top_k_hit_rate(df: pd.DataFrame, score_col: str, label_col: str, k: int = 10) -> float:
    hits = []
    for _, g in df.groupby('target_month'):
        top = g.nlargest(k, score_col)['cell_id']
        truth = set(g.loc[g[label_col] == 1, 'cell_id'])
        if not truth:
            continue
        hits.append(len(set(top).intersection(truth)) / min(k, len(truth)))
    return float(np.mean(hits)) if hits else np.nan


def make_lstm_sequences(df: pd.DataFrame, feature_cols: list[str], seq_len: int):
    X, y, keys = [], [], []
    for cell, g in df.groupby('cell_id'):
        g = g.sort_values('month')
        vals = g[feature_cols].values
        ys = g['target_hotspot'].values
        months = g['month'].values
        for i in range(seq_len - 1, len(g)):
            X.append(vals[i - seq_len + 1 : i + 1])
            y.append(ys[i])
            keys.append((cell, months[i]))
    return np.array(X, dtype=np.float32), np.array(y, dtype=np.float32), keys


def normalize_feature_frame(train_df: pd.DataFrame, val_df: pd.DataFrame, test_df: pd.DataFrame, feature_cols: list[str]):
    scaler = StandardScaler()
    train = train_df.copy()
    val = val_df.copy()
    test = test_df.copy()
    train[feature_cols] = scaler.fit_transform(train[feature_cols])
    val[feature_cols] = scaler.transform(val[feature_cols])
    test[feature_cols] = scaler.transform(test[feature_cols])
    return train, val, test


def eval_binary(y_true: pd.Series, probs: pd.Series, threshold: float) -> dict:
    pred = (probs >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    return {
        'accuracy': float(accuracy_score(y_true, pred)),
        'precision': float(precision_score(y_true, pred, zero_division=0)),
        'recall': float(recall_score(y_true, pred, zero_division=0)),
        'f1': float(f1_score(y_true, pred, zero_division=0)),
        'auc': float(roc_auc_score(y_true, probs)),
        'tn': int(tn),
        'fp': int(fp),
        'fn': int(fn),
        'tp': int(tp),
    }, pred


def plot_threshold_accuracy(curve_df: pd.DataFrame, out_path: Path):
    plt.figure(figsize=(10, 5))
    sns.lineplot(data=curve_df, x='threshold', y='val_accuracy', hue='model', linewidth=2)
    plt.axhline(0.80, color='gray', linestyle='--', linewidth=1)
    plt.axhline(0.90, color='gray', linestyle='--', linewidth=1)
    plt.title('Validation Accuracy vs Threshold')
    plt.ylim(0.4, 1.0)
    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()


def plot_confusion_matrices(comparison_df: pd.DataFrame, out_path: Path):
    models = comparison_df['model'].tolist()
    n = len(models)
    cols = 3
    rows = int(np.ceil(n / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(5 * cols, 4 * rows))
    axes = np.array(axes).reshape(rows, cols)

    for i, model in enumerate(models):
        r, c = divmod(i, cols)
        ax = axes[r, c]
        row = comparison_df[comparison_df['model'] == model].iloc[0]
        cm = np.array([[row['tn'], row['fp']], [row['fn'], row['tp']]], dtype=int)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False, ax=ax)
        ax.set_title(f"{model.upper()}\nAcc={row['accuracy']:.3f}, F1={row['f1']:.3f}")
        ax.set_xlabel('Predicted')
        ax.set_ylabel('Actual')

    for j in range(i + 1, rows * cols):
        r, c = divmod(j, cols)
        axes[r, c].axis('off')

    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()


def plot_roc_pr_curves(test_eval: pd.DataFrame, prob_cols: dict, roc_path: Path, pr_path: Path):
    y = test_eval['target_hotspot']

    plt.figure(figsize=(8, 6))
    for model, col in prob_cols.items():
        fpr, tpr, _ = roc_curve(y, test_eval[col])
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, linewidth=2, label=f'{model.upper()} (AUC={roc_auc:.3f})')
    plt.plot([0, 1], [0, 1], linestyle='--', color='gray')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC Curves - Hotspot Prediction')
    plt.legend()
    plt.tight_layout()
    plt.savefig(roc_path, dpi=150)
    plt.close()

    plt.figure(figsize=(8, 6))
    for model, col in prob_cols.items():
        precision, recall, _ = precision_recall_curve(y, test_eval[col])
        pr_auc = auc(recall, precision)
        plt.plot(recall, precision, linewidth=2, label=f'{model.upper()} (AUC={pr_auc:.3f})')
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall Curves - Hotspot Prediction')
    plt.legend()
    plt.tight_layout()
    plt.savefig(pr_path, dpi=150)
    plt.close()


def plot_lstm_history(history: tf.keras.callbacks.History | None, out_path: Path):
    if history is None:
        return
    hist = history.history
    if 'accuracy' not in hist or 'val_accuracy' not in hist:
        return

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    axes[0].plot(hist.get('accuracy', []), label='train_acc')
    axes[0].plot(hist.get('val_accuracy', []), label='val_acc')
    axes[0].set_title('LSTM Accuracy Curve')
    axes[0].set_xlabel('Epoch')
    axes[0].legend()

    axes[1].plot(hist.get('loss', []), label='train_loss')
    axes[1].plot(hist.get('val_loss', []), label='val_loss')
    axes[1].set_title('LSTM Loss Curve')
    axes[1].set_xlabel('Epoch')
    axes[1].legend()

    plt.tight_layout()
    plt.savefig(out_path, dpi=150)
    plt.close()


def plot_anomaly_graphs(test_eval: pd.DataFrame, out_cm: Path, out_dist: Path, out_monthly: Path):
    y_true = test_eval['true_anomaly']
    y_pred = test_eval['alert']
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])

    plt.figure(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Oranges', cbar=False)
    plt.title('Anomaly Alert Confusion Matrix')
    plt.xlabel('Predicted Alert')
    plt.ylabel('True Anomaly')
    plt.tight_layout()
    plt.savefig(out_cm, dpi=150)
    plt.close()

    plt.figure(figsize=(8, 5))
    sns.kdeplot(data=test_eval, x='anomaly_score', hue='true_anomaly', fill=True, common_norm=False)
    plt.title('Anomaly Score Distribution by True Anomaly')
    plt.tight_layout()
    plt.savefig(out_dist, dpi=150)
    plt.close()

    monthly = test_eval.groupby('target_month').agg(
        alerts=('alert', 'sum'),
        true_anomalies=('true_anomaly', 'sum'),
    ).reset_index()

    plt.figure(figsize=(10, 5))
    x = np.arange(len(monthly))
    width = 0.38
    plt.bar(x - width / 2, monthly['alerts'], width=width, label='Predicted Alerts')
    plt.bar(x + width / 2, monthly['true_anomalies'], width=width, label='True Anomalies')
    plt.xticks(x, monthly['target_month'], rotation=45)
    plt.title('Monthly Anomaly Alerts vs True Anomalies')
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_monthly, dpi=150)
    plt.close()



def search_super_ensemble_weights(val_eval: pd.DataFrame, component_cols: list[str]) -> dict:
    best = None
    grid = np.arange(0.0, 1.01, 0.1)

    for w_rf in grid:
        for w_xgb in grid:
            for w_lstm in grid:
                w_hist = 1.0 - (w_rf + w_xgb + w_lstm)
                if w_hist < 0 or w_hist > 1:
                    continue

                probs = (
                    w_rf * val_eval[component_cols[0]] +
                    w_xgb * val_eval[component_cols[1]] +
                    w_lstm * val_eval[component_cols[2]] +
                    w_hist * val_eval[component_cols[3]]
                )
                threshold, acc, f1 = choose_threshold(val_eval['target_hotspot'], probs)
                score = 0.6 * f1 + 0.4 * acc
                cand = (score, acc, f1, threshold, w_rf, w_xgb, w_lstm, w_hist)
                if best is None or cand > best:
                    best = cand

    _, acc, f1, threshold, w_rf, w_xgb, w_lstm, w_hist = best
    return {
        'w_rf': float(w_rf),
        'w_xgb': float(w_xgb),
        'w_lstm': float(w_lstm),
        'w_hist': float(w_hist),
        'threshold': float(threshold),
        'val_accuracy': float(acc),
        'val_f1': float(f1),
    }


def compute_monthly_backtest(df: pd.DataFrame, prob_col: str, pred_col: str) -> pd.DataFrame:
    rows = []
    for month, g in df.groupby('target_month'):
        y = g['target_hotspot']
        p = g[pred_col]
        topk = g.nlargest(10, prob_col)
        truth = set(g.loc[g['target_hotspot'] == 1, 'cell_id'])
        hit_rate = len(set(topk['cell_id']).intersection(truth)) / max(1, min(10, len(truth)))

        rows.append({
            'target_month': month,
            'accuracy': float(accuracy_score(y, p)),
            'precision': float(precision_score(y, p, zero_division=0)),
            'recall': float(recall_score(y, p, zero_division=0)),
            'f1': float(f1_score(y, p, zero_division=0)),
            'predicted_hotspots': int(p.sum()),
            'actual_hotspots': int(y.sum()),
            'top10_hit_rate': float(hit_rate),
        })

    return pd.DataFrame(rows).sort_values('target_month').reset_index(drop=True)


def plot_backtesting_graphs(backtest_df: pd.DataFrame, metric_path: Path, counts_path: Path, hit_path: Path):
    plt.figure(figsize=(10, 5))
    for col in ['accuracy', 'precision', 'recall', 'f1']:
        plt.plot(backtest_df['target_month'], backtest_df[col], marker='o', label=col)
    plt.xticks(rotation=45)
    plt.ylim(0, 1.05)
    plt.title('Backtesting Metrics by Month')
    plt.legend()
    plt.tight_layout()
    plt.savefig(metric_path, dpi=150)
    plt.close()

    plt.figure(figsize=(10, 5))
    x = np.arange(len(backtest_df))
    width = 0.4
    plt.bar(x - width / 2, backtest_df['predicted_hotspots'], width=width, label='Predicted')
    plt.bar(x + width / 2, backtest_df['actual_hotspots'], width=width, label='Actual')
    plt.xticks(x, backtest_df['target_month'], rotation=45)
    plt.title('Backtesting Hotspot Counts (Predicted vs Actual)')
    plt.legend()
    plt.tight_layout()
    plt.savefig(counts_path, dpi=150)
    plt.close()

    plt.figure(figsize=(10, 5))
    plt.plot(backtest_df['target_month'], backtest_df['top10_hit_rate'], marker='o', color='darkgreen')
    plt.xticks(rotation=45)
    plt.ylim(0, 1.05)
    plt.title('Backtesting Top-10 Hit Rate by Month')
    plt.tight_layout()
    plt.savefig(hit_path, dpi=150)
    plt.close()


def create_google_base_map(center_lat: float, center_lon: float, zoom: int = 12) -> folium.Map:
    m = folium.Map(location=[center_lat, center_lon], zoom_start=zoom, tiles=None, control_scale=True)
    folium.TileLayer(
        tiles='https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
        attr='Google',
        name='Google Maps',
        overlay=False,
        control=True,
    ).add_to(m)
    return m


def generate_google_hotspot_backtest_map(df: pd.DataFrame, pred_col: str, out_path: Path):
    if df.empty:
        return

    m = create_google_base_map(float(df['lat_center'].mean()), float(df['lon_center'].mean()), zoom=13)

    for _, row in df.iterrows():
        actual = int(row['target_hotspot'])
        pred = int(row[pred_col])

        if actual == 1 and pred == 1:
            color = 'green'
            label = 'True Positive Hotspot'
        elif actual == 1 and pred == 0:
            color = 'red'
            label = 'Missed Real Hotspot'
        elif actual == 0 and pred == 1:
            color = 'blue'
            label = 'Predicted but Not Real'
        else:
            continue

        popup = (
            f"Month: {row['target_month']}<br>Cell: {row['cell_id']}<br>"
            f"Hotspot: {row.get('hotspot_name', 'Unknown')}<br>"
            f"Dominant Crime: {row.get('dominant_crime_type', 'Unknown')}<br>"
            f"Prob: {row['selected_prob']:.3f}<br>Actual: {actual}, Pred: {pred}<br>{label}"
        )

        folium.CircleMarker(
            location=[row['lat_center'], row['lon_center']],
            radius=5,
            color=color,
            fill=True,
            fill_opacity=0.8,
            popup=popup,
        ).add_to(m)

    legend_html = """
    <div style='position: fixed; bottom: 50px; left: 50px; width: 260px; z-index: 9999;
    background: white; border: 2px solid #666; padding: 10px; font-size: 12px;'>
    <b>Backtest Hotspots (Google Map)</b><br>
    <span style='color:green'>Green</span>: True Positive Hotspot<br>
    <span style='color:red'>Red</span>: Missed Real Hotspot<br>
    <span style='color:blue'>Blue</span>: Predicted but Not Real
    </div>
    """
    m.get_root().html.add_child(folium.Element(legend_html))
    m.save(str(out_path))


def generate_google_forecast_map(df: pd.DataFrame, out_path: Path, selected_model_name: str):
    if df.empty:
        return

    m = create_google_base_map(float(df['lat_center'].mean()), float(df['lon_center'].mean()), zoom=13)

    selected_label = selected_model_name.upper()
    for i, row in enumerate(df.itertuples(index=False), start=1):
        selected_prob = getattr(row, 'selected_model_prob', np.nan)
        popup = (
            f"Rank: {i}<br>Cell: {row.cell_id}<br>"
            f"Hotspot: {getattr(row, 'hotspot_name', 'Unknown')}<br>"
            f"Dominant Crime: {getattr(row, 'dominant_crime_type', 'Unknown')}<br>"
            f"Forecast Risk: {row.forecast_risk:.3f}<br>"
            f"{selected_label} Prob: {selected_prob:.3f}"
        )
        folium.CircleMarker(
            location=[row.lat_center, row.lon_center],
            radius=5 + min(6, row.forecast_risk * 8),
            color='purple',
            fill=True,
            fill_opacity=0.75,
            popup=popup,
        ).add_to(m)

    m.save(str(out_path))

def main():
    session = get_session()
    latest = get_latest_month(session)
    months = month_window(latest, N_MONTHS)

    print('API mode:', API_MODE)
    print('Latest month from API:', latest)
    print('Using months:', months[0], 'to', months[-1], f'({len(months)} months)')

    rows = []
    for month in months:
        m_rows = fetch_month_from_api(session, month)
        rows.extend(m_rows)
        print(f'Fetched {month}: {len(m_rows)} incidents (from API)')

    incidents = add_grid(build_incident_frame(rows))
    panel_full = build_panel(incidents, months)
    panel = panel_full[panel_full['target_count'].notna()].copy()
    panel['target_month'] = (
        pd.to_datetime(panel['month'] + '-01') + pd.offsets.MonthBegin(1)
    ).dt.strftime('%Y-%m')

    feature_cols = [
        'crime_count', 'lag1', 'lag2', 'lag3',
        'roll_mean_3', 'roll_mean_6', 'roll_std_3',
        'spatial_lag', 'hotspot_persistence',
        'month_sin', 'month_cos',
        'lat_bin', 'lon_bin',
    ]
    panel[feature_cols] = panel[feature_cols].replace([np.inf, -np.inf], np.nan).fillna(0)

    train_months, val_months, test_months = temporal_split(panel)
    train = panel[panel['month'].isin(train_months)].copy()
    val = panel[panel['month'].isin(val_months)].copy()
    test = panel[panel['month'].isin(test_months)].copy()

    hotspot_threshold = float(train['target_count'].quantile(0.60))
    for df in (train, val, test, panel):
        df['target_hotspot'] = (df['target_count'] >= hotspot_threshold).astype(int)

    X_train, y_train = train[feature_cols], train['target_hotspot']
    X_val, y_val = val[feature_cols], val['target_hotspot']
    X_test, y_test = test[feature_cols], test['target_hotspot']

    # -------------------------
    # Model 1: Random Forest
    # -------------------------
    rf = RandomForestClassifier(
        n_estimators=400,
        max_depth=12,
        min_samples_leaf=2,
        class_weight='balanced',
        random_state=SEED,
        n_jobs=-1,
    )
    rf.fit(X_train, y_train)
    rf_val_prob = rf.predict_proba(X_val)[:, 1]
    rf_test_prob = rf.predict_proba(X_test)[:, 1]

    # -------------------------
    # Model 2: XGBoost
    # -------------------------
    pos = max(1, int(y_train.sum()))
    neg = max(1, int((y_train == 0).sum()))
    xgb = XGBClassifier(
        n_estimators=500,
        learning_rate=0.05,
        max_depth=6,
        subsample=0.85,
        colsample_bytree=0.85,
        objective='binary:logistic',
        eval_metric='logloss',
        reg_lambda=1.0,
        random_state=SEED,
        n_jobs=-1,
        scale_pos_weight=neg / pos,
    )
    xgb.fit(X_train, y_train)
    xgb_val_prob = xgb.predict_proba(X_val)[:, 1]
    xgb_test_prob = xgb.predict_proba(X_test)[:, 1]

    # -------------------------
    # Model 3: LSTM
    # -------------------------
    train_s, val_s, test_s = normalize_feature_frame(train, val, test, feature_cols)
    X_train_seq, y_train_seq, train_keys = make_lstm_sequences(train_s, feature_cols, SEQ_LEN)
    X_val_seq, y_val_seq, val_keys = make_lstm_sequences(val_s, feature_cols, SEQ_LEN)
    X_test_seq, y_test_seq, test_keys = make_lstm_sequences(test_s, feature_cols, SEQ_LEN)

    lstm_prob_val_map = {}
    lstm_prob_test_map = {}
    history = None

    if len(X_train_seq) > 0 and len(X_val_seq) > 0 and len(X_test_seq) > 0:
        lstm = Sequential([
            Input(shape=(SEQ_LEN, len(feature_cols))),
            LSTM(32, dropout=0.2),
            Dense(16, activation='relu'),
            Dense(1, activation='sigmoid'),
        ])
        lstm.compile(
            optimizer='adam',
            loss='binary_crossentropy',
            metrics=['accuracy', tf.keras.metrics.AUC(name='auc')],
        )
        class_weights = {
            0: 1.0,
            1: float((len(y_train_seq) - y_train_seq.sum()) / max(y_train_seq.sum(), 1.0)),
        }
        history = lstm.fit(
            X_train_seq,
            y_train_seq,
            validation_data=(X_val_seq, y_val_seq),
            epochs=35,
            batch_size=64,
            verbose=0,
            callbacks=[EarlyStopping(monitor='val_auc', mode='max', patience=5, restore_best_weights=True)],
            class_weight=class_weights,
        )
        val_probs = lstm.predict(X_val_seq, verbose=0).ravel()
        test_probs = lstm.predict(X_test_seq, verbose=0).ravel()
        lstm_prob_val_map = {k: p for k, p in zip(val_keys, val_probs)}
        lstm_prob_test_map = {k: p for k, p in zip(test_keys, test_probs)}

    val_eval = val[
        [
            'cell_id',
            'month',
            'target_month',
            'target_hotspot',
            'target_count',
            'hotspot_persistence',
            'lat_center',
            'lon_center',
            'hotspot_name',
            'dominant_crime_type',
        ]
    ].copy()
    test_eval = test[
        [
            'cell_id',
            'month',
            'target_month',
            'target_hotspot',
            'target_count',
            'hotspot_persistence',
            'lat_center',
            'lon_center',
            'hotspot_name',
            'dominant_crime_type',
        ]
    ].copy()

    # Static KDE baseline over spatial coordinates (trained on historical incidents only).
    kde_fallback = float(train['target_hotspot'].mean())
    kde_model = None
    kde_scaler = None
    train_incident_coords = incidents.loc[incidents['month'].isin(train_months), ['lat', 'lon']].dropna().values
    if len(train_incident_coords) >= 10:
        kde_model = KernelDensity(kernel='gaussian', bandwidth=max(0.001, GRID_SIZE * 1.5))
        kde_model.fit(train_incident_coords)

        train_cell_coords = train[['lat_center', 'lon_center']].dropna().drop_duplicates().values
        if len(train_cell_coords) == 0:
            train_cell_coords = train[['lat_center', 'lon_center']].dropna().values

        train_kde_log = kde_model.score_samples(train_cell_coords)
        kde_scaler = MinMaxScaler().fit(train_kde_log.reshape(-1, 1))

        val_kde_log = kde_model.score_samples(val_eval[['lat_center', 'lon_center']].values)
        test_kde_log = kde_model.score_samples(test_eval[['lat_center', 'lon_center']].values)
        val_eval['kde_prob'] = kde_scaler.transform(val_kde_log.reshape(-1, 1)).ravel()
        test_eval['kde_prob'] = kde_scaler.transform(test_kde_log.reshape(-1, 1)).ravel()
    else:
        val_eval['kde_prob'] = kde_fallback
        test_eval['kde_prob'] = kde_fallback

    val_eval['rf_prob'] = rf_val_prob
    val_eval['xgb_prob'] = xgb_val_prob
    val_eval['lstm_prob'] = [lstm_prob_val_map.get((c, m), np.nan) for c, m in zip(val_eval['cell_id'], val_eval['month'])]

    test_eval['rf_prob'] = rf_test_prob
    test_eval['xgb_prob'] = xgb_test_prob
    test_eval['lstm_prob'] = [lstm_prob_test_map.get((c, m), np.nan) for c, m in zip(test_eval['cell_id'], test_eval['month'])]

    # Backfill missing LSTM values using average of tree models to preserve row alignment.
    val_eval['lstm_prob'] = val_eval['lstm_prob'].fillna((val_eval['rf_prob'] + val_eval['xgb_prob']) / 2)
    test_eval['lstm_prob'] = test_eval['lstm_prob'].fillna((test_eval['rf_prob'] + test_eval['xgb_prob']) / 2)

    # Combined model implementation: equal-weight probability fusion.
    val_eval['ensemble_prob'] = (val_eval['rf_prob'] + val_eval['xgb_prob'] + val_eval['lstm_prob']) / 3.0
    test_eval['ensemble_prob'] = (test_eval['rf_prob'] + test_eval['xgb_prob'] + test_eval['lstm_prob']) / 3.0

    hist_prob = train.groupby('cell_id')['target_hotspot'].mean().to_dict()
    val_eval['hist_prob'] = val_eval['cell_id'].map(hist_prob).fillna(float(train['target_hotspot'].mean()))
    test_eval['hist_prob'] = test_eval['cell_id'].map(hist_prob).fillna(float(train['target_hotspot'].mean()))

    blend = search_super_ensemble_weights(val_eval, ['rf_prob', 'xgb_prob', 'lstm_prob', 'hist_prob'])
    val_eval['super_ensemble_prob'] = (
        blend['w_rf'] * val_eval['rf_prob'] +
        blend['w_xgb'] * val_eval['xgb_prob'] +
        blend['w_lstm'] * val_eval['lstm_prob'] +
        blend['w_hist'] * val_eval['hist_prob']
    )
    test_eval['super_ensemble_prob'] = (
        blend['w_rf'] * test_eval['rf_prob'] +
        blend['w_xgb'] * test_eval['xgb_prob'] +
        blend['w_lstm'] * test_eval['lstm_prob'] +
        blend['w_hist'] * test_eval['hist_prob']
    )

    prob_cols = {
        'rf': 'rf_prob',
        'xgb': 'xgb_prob',
        'lstm': 'lstm_prob',
        'ensemble': 'ensemble_prob',
        'super_ensemble': 'super_ensemble_prob',
        'kde_baseline': 'kde_prob',
        'baseline': 'hist_prob',
    }

    comparison_rows = []
    threshold_rows = []
    test_pred_cols = {}

    for model_name, col in prob_cols.items():
        if model_name == 'super_ensemble':
            threshold = blend['threshold']
            val_acc = blend['val_accuracy']
            val_f1 = blend['val_f1']
        else:
            threshold, val_acc, val_f1 = choose_threshold(val_eval['target_hotspot'], val_eval[col])

        test_metrics, pred = eval_binary(test_eval['target_hotspot'], test_eval[col], threshold)
        test_eval[f'{model_name}_pred'] = pred
        test_pred_cols[model_name] = f'{model_name}_pred'

        comparison_rows.append({
            'model': model_name,
            'threshold': threshold,
            'val_accuracy': val_acc,
            'val_f1': val_f1,
            **test_metrics,
        })

        for t in np.linspace(0.1, 0.9, 41):
            threshold_rows.append({
                'model': model_name,
                'threshold': float(t),
                'val_accuracy': float(accuracy_score(val_eval['target_hotspot'], (val_eval[col] >= t).astype(int))),
            })

    comparison_df = pd.DataFrame(comparison_rows).sort_values(['accuracy', 'f1'], ascending=False).reset_index(drop=True)
    threshold_curve_df = pd.DataFrame(threshold_rows)

    # Select best model only from the methodology family in the proposed document.
    methodology_models = ['rf', 'xgb', 'lstm', 'ensemble']
    candidate_df = comparison_df[comparison_df['model'].isin(methodology_models)].copy()
    if candidate_df.empty:
        candidate_df = comparison_df.copy()
    selected_row = candidate_df.sort_values(['accuracy', 'f1'], ascending=False).iloc[0]
    selected_model = selected_row['model']
    selected_prob_col = prob_cols[selected_model]
    selected_pred_col = f'{selected_model}_pred'

    # -------------------------
    # Anomaly module
    # -------------------------
    reg = RandomForestRegressor(
        n_estimators=300,
        max_depth=14,
        min_samples_leaf=2,
        random_state=SEED,
        n_jobs=-1,
    )
    reg.fit(X_train, train['target_count'])
    train_pred_count = reg.predict(X_train)
    test_pred_count = reg.predict(X_test)

    train_resid = train['target_count'].values - train_pred_count
    test_resid = test['target_count'].values - test_pred_count

    train_resid_df = train[['cell_id']].copy()
    train_resid_df['resid'] = train_resid
    cell_med = train_resid_df.groupby('cell_id')['resid'].median()
    cell_mad = (
        (train_resid_df['resid'] - train_resid_df['cell_id'].map(cell_med)).abs()
        .groupby(train_resid_df['cell_id'])
        .median()
        .replace(0, 1e-6)
    )

    test_eval['expected_count'] = test_pred_count
    test_eval['residual'] = test_resid
    test_eval['resid_median'] = test_eval['cell_id'].map(cell_med).fillna(train_resid_df['resid'].median())
    global_resid_mad = np.mean(np.abs(train_resid_df['resid'] - train_resid_df['resid'].mean())) + 1e-6
    test_eval['resid_mad'] = test_eval['cell_id'].map(cell_mad).fillna(global_resid_mad)
    test_eval['z_score'] = (test_eval['residual'] - test_eval['resid_median']) / (test_eval['resid_mad'] + 1e-6)

    iforest = IsolationForest(n_estimators=250, contamination=0.08, random_state=SEED)
    train_if_features = np.column_stack([
        train_resid,
        np.abs(train_resid),
        train['lag1'].values,
        train['roll_mean_3'].values,
    ])
    test_if_features = np.column_stack([
        test_resid,
        np.abs(test_resid),
        test['lag1'].values,
        test['roll_mean_3'].values,
    ])
    iforest.fit(train_if_features)
    train_if_score = -iforest.score_samples(train_if_features)
    test_if_score = -iforest.score_samples(test_if_features)

    mm_if = MinMaxScaler().fit(train_if_score.reshape(-1, 1))
    test_eval['if_score'] = mm_if.transform(test_if_score.reshape(-1, 1)).ravel()
    test_eval['z_abs_norm'] = np.clip(np.abs(test_eval['z_score']) / 5.0, 0, 1)

    alpha = 0.55
    w1, w2, w3, w4 = 0.55, 0.25, 0.10, 0.10
    test_eval['anomaly_score'] = alpha * test_eval['if_score'] + (1 - alpha) * test_eval['z_abs_norm']
    test_eval['confidence_score'] = np.clip(np.abs(test_eval[selected_prob_col] - 0.5) * 2.0, 0, 1)
    test_eval['composite_risk'] = (
        w1 * test_eval[selected_prob_col] +
        w2 * test_eval['anomaly_score'] +
        w3 * test_eval['hotspot_persistence'] +
        w4 * test_eval['confidence_score']
    )

    test_eval = test_eval.sort_values(['cell_id', 'target_month']).reset_index(drop=True)
    test_eval['anomaly_persist_2'] = (
        test_eval.groupby('cell_id')['anomaly_score']
        .rolling(2, min_periods=1)
        .mean()
        .reset_index(level=0, drop=True)
    )

    tau = test_eval['composite_risk'].quantile(0.8)
    p_min = test_eval['anomaly_score'].quantile(0.75)
    test_eval['alert'] = ((test_eval['composite_risk'] >= tau) & (test_eval['anomaly_persist_2'] >= p_min)).astype(int)

    count_med = train.groupby('cell_id')['target_count'].median()
    count_mad = (
        (train['target_count'] - train['cell_id'].map(count_med)).abs()
        .groupby(train['cell_id'])
        .median()
        .replace(0, 1e-6)
    )
    test_eval['count_med'] = test_eval['cell_id'].map(count_med).fillna(train['target_count'].median())
    global_count_mad = np.mean(np.abs(train['target_count'] - train['target_count'].mean())) + 1e-6
    test_eval['count_mad'] = test_eval['cell_id'].map(count_mad).fillna(global_count_mad)
    test_eval['true_anomaly'] = (
        test_eval['target_count'] > (test_eval['count_med'] + 2.0 * test_eval['count_mad'])
    ).astype(int)

    anomaly_metrics, _ = eval_binary(test_eval['true_anomaly'], test_eval['anomaly_score'], float(p_min))
    alert_metrics = {
        'alert_precision': float(precision_score(test_eval['true_anomaly'], test_eval['alert'], zero_division=0)),
        'alert_recall': float(recall_score(test_eval['true_anomaly'], test_eval['alert'], zero_division=0)),
        'alert_f1': float(f1_score(test_eval['true_anomaly'], test_eval['alert'], zero_division=0)),
        'alert_accuracy': float(accuracy_score(test_eval['true_anomaly'], test_eval['alert'])),
    }

    # Backtesting artifacts using best-performing methodology model.
    test_eval['selected_prob'] = test_eval[selected_prob_col]
    test_eval['selected_pred'] = test_eval[selected_pred_col]
    test_eval['selected_model'] = selected_model

    backtest_df = compute_monthly_backtest(test_eval, selected_prob_col, selected_pred_col)
    backtest_df.to_csv(OUT_DIR / 'backtest_monthly_metrics.csv', index=False)

    plot_backtesting_graphs(
        backtest_df,
        FIG_DIR / 'backtest_metrics_over_time.png',
        FIG_DIR / 'backtest_hotspot_counts_over_time.png',
        FIG_DIR / 'backtest_top10_hit_rate.png',
    )

    latest_test_month = max(test_eval['target_month'])
    latest_test_df = test_eval[test_eval['target_month'] == latest_test_month].copy()
    generate_google_hotspot_backtest_map(latest_test_df, selected_pred_col, FIG_DIR / 'backtest_hotspots_google_map.html')

    # -------------------------
    # Save plots
    # -------------------------
    plot_threshold_accuracy(threshold_curve_df, FIG_DIR / 'threshold_accuracy_curve.png')
    plot_confusion_matrices(comparison_df, FIG_DIR / 'model_confusion_matrices.png')
    plot_roc_pr_curves(test_eval, prob_cols, FIG_DIR / 'roc_curves.png', FIG_DIR / 'precision_recall_curves.png')
    plot_lstm_history(history, FIG_DIR / 'lstm_training_curves.png')
    plot_anomaly_graphs(
        test_eval,
        FIG_DIR / 'anomaly_confusion_matrix.png',
        FIG_DIR / 'anomaly_score_distribution.png',
        FIG_DIR / 'anomaly_monthly_alerts.png',
    )

    # -------------------------
    # Save tables and metrics
    # -------------------------
    comparison_df.to_csv(OUT_DIR / 'model_comparison.csv', index=False)
    threshold_curve_df.to_csv(OUT_DIR / 'threshold_accuracy_curve.csv', index=False)

    out_cols = [
        'cell_id', 'hotspot_name', 'dominant_crime_type', 'month', 'target_month', 'lat_center', 'lon_center',
        'target_count', 'target_hotspot',
        'kde_prob', 'rf_prob', 'xgb_prob', 'lstm_prob', 'ensemble_prob', 'super_ensemble_prob', 'hist_prob',
        'kde_baseline_pred', 'rf_pred', 'xgb_pred', 'lstm_pred', 'ensemble_pred', 'super_ensemble_pred', 'baseline_pred',
        'selected_prob', 'selected_pred', 'selected_model',
        'expected_count', 'residual', 'z_score', 'if_score', 'confidence_score',
        'anomaly_score', 'composite_risk', 'alert', 'true_anomaly',
    ]
    test_eval[out_cols].to_csv(OUT_DIR / 'test_predictions.csv', index=False)

    latest_anomaly_month = max(test_eval['target_month'])
    latest_anomaly = (
        test_eval[test_eval['target_month'] == latest_anomaly_month]
        .sort_values('composite_risk', ascending=False)
        .head(25)
    )
    latest_anomaly[out_cols].to_csv(OUT_DIR / 'latest_anomaly_alerts.csv', index=False)

    latest_month = max(months)
    forecast_rows = panel_full[panel_full['month'] == latest_month].copy()
    forecast_rows[feature_cols] = forecast_rows[feature_cols].replace([np.inf, -np.inf], np.nan).fillna(0)
    forecast_rows['rf_prob'] = rf.predict_proba(forecast_rows[feature_cols])[:, 1]
    forecast_rows['xgb_prob'] = xgb.predict_proba(forecast_rows[feature_cols])[:, 1]
    forecast_rows['lstm_prob'] = (forecast_rows['rf_prob'] + forecast_rows['xgb_prob']) / 2
    forecast_rows['ensemble_prob'] = (forecast_rows['rf_prob'] + forecast_rows['xgb_prob'] + forecast_rows['lstm_prob']) / 3.0
    forecast_rows['hist_prob'] = forecast_rows['cell_id'].map(hist_prob).fillna(float(train['target_hotspot'].mean()))
    if kde_model is not None and kde_scaler is not None:
        forecast_kde_log = kde_model.score_samples(forecast_rows[['lat_center', 'lon_center']].values)
        forecast_rows['kde_prob'] = kde_scaler.transform(forecast_kde_log.reshape(-1, 1)).ravel()
    else:
        forecast_rows['kde_prob'] = kde_fallback
    forecast_rows['super_ensemble_prob'] = (
        blend['w_rf'] * forecast_rows['rf_prob'] +
        blend['w_xgb'] * forecast_rows['xgb_prob'] +
        blend['w_lstm'] * forecast_rows['lstm_prob'] +
        blend['w_hist'] * forecast_rows['hist_prob']
    )
    forecast_rows['selected_model_prob'] = forecast_rows[selected_prob_col]
    forecast_rows['selected_model'] = selected_model
    forecast_rows['forecast_risk'] = 0.75 * forecast_rows['selected_model_prob'] + 0.25 * forecast_rows['hotspot_persistence']
    top_alerts = forecast_rows.nlargest(25, 'forecast_risk')[
        [
            'cell_id',
            'hotspot_name',
            'dominant_crime_type',
            'month',
            'lat_center',
            'lon_center',
            'crime_count',
            'lag1',
            'selected_model',
            'selected_model_prob',
            'super_ensemble_prob',
            'hotspot_persistence',
            'forecast_risk',
        ]
    ]
    top_alerts.to_csv(OUT_DIR / 'next_month_top_alerts.csv', index=False)
    generate_google_forecast_map(top_alerts, FIG_DIR / 'forecast_hotspots_google_map.html', selected_model)

    run_utc = datetime.now(timezone.utc)
    run_uk = run_utc.astimezone(ZoneInfo('Europe/London'))
    current_calendar_month = run_uk.strftime('%Y-%m')
    current_period = pd.Period(current_calendar_month, freq='M')
    latest_period = pd.Period(latest, freq='M')
    api_lag_months = max(0, current_period.ordinal - latest_period.ordinal)

    metrics = {
        'run_utc': run_utc.isoformat(),
        'run_uk_datetime': run_uk.isoformat(),
        'run_uk_date': run_uk.strftime('%Y-%m-%d'),
        'current_calendar_month': current_calendar_month,
        'api_mode': API_MODE,
        'data_source': 'UK Police Data API (https://data.police.uk)',
        'latest_api_month': latest,
        'available_data_upto_month': latest,
        'api_publication_lag_months': api_lag_months,
        'data_currency_note': (
            f"As of {run_uk.strftime('%Y-%m-%d')}, UK Police API has published data up to {latest}."
        ),
        'history_months_used': len(months),
        'history_start_month': months[0],
        'history_end_month': months[-1],
        'ensemble_formula': 'ensemble_prob = (rf_prob + xgb_prob + lstm_prob) / 3',
        'super_ensemble_formula': (
            f"super_ensemble_prob = {blend['w_rf']:.2f}*rf + {blend['w_xgb']:.2f}*xgb + "
            f"{blend['w_lstm']:.2f}*lstm + {blend['w_hist']:.2f}*hist"
        ),
        'methodology_models': methodology_models,
        'selected_model_for_reporting': selected_model,
        'selected_probability_column': selected_prob_col,
        'composite_risk_formula': (
            'composite_risk = 0.55*selected_prob + 0.25*anomaly_score + '
            '0.10*hotspot_persistence + 0.10*confidence_score'
        ),
        'test_accuracy': float(selected_row['accuracy']),
        'test_precision': float(selected_row['precision']),
        'test_recall': float(selected_row['recall']),
        'test_f1': float(selected_row['f1']),
        'test_auc': float(selected_row['auc']),
        'threshold': float(selected_row['threshold']),
        'top10_hit_rate': top_k_hit_rate(test_eval, selected_prob_col, 'target_hotspot', k=10),
        'anomaly_precision': alert_metrics['alert_precision'],
        'anomaly_recall': alert_metrics['alert_recall'],
        'anomaly_f1': alert_metrics['alert_f1'],
        'anomaly_accuracy': alert_metrics['alert_accuracy'],
        'maps': {
            'backtest_hotspots_google_map': str(FIG_DIR / 'backtest_hotspots_google_map.html'),
            'forecast_hotspots_google_map': str(FIG_DIR / 'forecast_hotspots_google_map.html'),
        },
    }

    with (OUT_DIR / 'metrics.json').open('w', encoding='utf-8') as f:
        json.dump(metrics, f, indent=2)

    print('\n=== MODEL COMPARISON (TEST) ===')
    print(comparison_df[['model', 'accuracy', 'precision', 'recall', 'f1', 'auc', 'threshold']].to_string(index=False))

    print('\n=== SELECTED MODEL ===')
    print('selected_model_for_reporting:', selected_model)
    print('super_ensemble_formula:', metrics['super_ensemble_formula'])
    print('run_uk_date:', metrics['run_uk_date'])
    print('current_calendar_month:', metrics['current_calendar_month'])
    print('available_data_upto_month:', metrics['available_data_upto_month'])
    print('api_publication_lag_months:', metrics['api_publication_lag_months'])

    print('\n=== SELECTED METRICS ===')
    for key in ['test_accuracy', 'test_precision', 'test_recall', 'test_f1', 'test_auc', 'threshold']:
        print(f'{key}: {metrics[key]:.4f}')

    print('\n=== ANOMALY ALERT METRICS ===')
    for key in ['anomaly_precision', 'anomaly_recall', 'anomaly_f1', 'anomaly_accuracy']:
        print(f'{key}: {metrics[key]:.4f}')

    print('\nSaved artifacts:')
    print('-', OUT_DIR / 'metrics.json')
    print('-', OUT_DIR / 'model_comparison.csv')
    print('-', OUT_DIR / 'backtest_monthly_metrics.csv')
    print('-', OUT_DIR / 'test_predictions.csv')
    print('-', OUT_DIR / 'next_month_top_alerts.csv')
    print('-', OUT_DIR / 'latest_anomaly_alerts.csv')
    print('-', FIG_DIR / 'backtest_hotspots_google_map.html')
    print('-', FIG_DIR / 'forecast_hotspots_google_map.html')
    print('-', FIG_DIR)


if __name__ == '__main__':
    main()
