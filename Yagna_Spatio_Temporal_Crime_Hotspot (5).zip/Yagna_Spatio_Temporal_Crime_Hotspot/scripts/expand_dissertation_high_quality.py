from __future__ import annotations

from pathlib import Path
import re
from collections import Counter

from docx import Document
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph


DOC_PATH = Path(
    r"c:\Users\yegam\OneDrive\Documents\Dissertation\Yagna_Spatio_Temporal_Crime_Hotspot\Yagna_Final_Dissertation.docx"
)


def insert_paragraph_after(paragraph: Paragraph, text: str, style: str = "Normal") -> Paragraph:
    new_p = OxmlElement("w:p")
    paragraph._p.addnext(new_p)
    new_para = Paragraph(new_p, paragraph._parent)
    new_para.style = style
    new_para.add_run(text)
    return new_para


def word_count_excluding_references(doc: Document) -> int:
    ref_idx = None
    for i, para in enumerate(doc.paragraphs):
        if para.style.name == "Heading 1" and para.text.strip().lower() == "references":
            ref_idx = i
            break
    if ref_idx is None:
        ref_idx = len(doc.paragraphs)
    text = "\n".join(p.text for p in doc.paragraphs[:ref_idx])
    return len(re.findall(r"\b[\w'-]+\b", text))


def duplicate_long_paragraphs(doc: Document) -> list[tuple[int, str]]:
    bucket: list[str] = []
    for p in doc.paragraphs:
        t = " ".join(p.text.split()).strip()
        if len(t) >= 120:
            bucket.append(t)
    c = Counter(bucket)
    return sorted([(n, t) for t, n in c.items() if n > 1], reverse=True)


EXPANSIONS: dict[str, list[str]] = {
    "1.1 Background": [
        (
            "A further point of context is the mismatch between how crime risk forms and how operational decisions are usually timed. "
            "Risk formation is continuous and adaptive: footfall patterns shift by hour, guardianship changes with transport flows, and "
            "opportunity structures are reconfigured by local events, retail peaks, and venue closing times. Operational decisions, however, "
            "are commonly taken in discrete review cycles and are often constrained by administrative reporting periods rather than behavioral "
            "dynamics. This mismatch does not invalidate monthly analysis, but it does create a translation problem: model outputs must be "
            "constructed so they can survive this temporal aggregation without losing the local signals that make forecasting useful. In practical "
            "terms, that means feature engineering has to carry short-memory effects and persistence effects at the same time, and evaluation has "
            "to test whether ranked priorities remain stable as monthly conditions move. A system that gives different high-priority zones every "
            "run without clear rationale may be mathematically responsive yet operationally unusable. Conversely, a system that merely repeats "
            "historical hotspots can appear stable while failing to detect newly emerging pressure points. This dissertation therefore treats "
            "background theory not as descriptive framing alone, but as a design constraint: useful intelligence must balance temporal sensitivity, "
            "spatial specificity, and practical continuity across planning cycles."
        )
    ],
    "1.2 Problem Statement": [
        (
            "The problem can also be expressed as a three-layer decision-quality failure. At the data layer, delayed publication and partial location "
            "anonymisation can encourage overconfident interpretation when models are presented without explicit caveats. At the modelling layer, "
            "single-task pipelines often optimise one objective, such as hotspot classification, while ignoring adjacent objectives that matter for "
            "decision timing, such as sudden surge detection. At the governance layer, many systems do not provide enough traceable evidence for an "
            "analyst to understand why a specific area was elevated above another area with similar historical volume. These three failures interact: "
            "when data constraints are opaque, model outputs are harder to trust; when model objectives are fragmented, operational users must "
            "manually reconcile conflicting signals; and when explanation is weak, accountability shifts from system design to individual discretion. "
            "The dissertation treats this as a systems engineering challenge rather than a purely algorithmic challenge. The core claim is not that "
            "one model architecture is universally superior, but that integrated design choices can materially improve reliability of prioritisation "
            "under constrained information conditions. This framing justifies the explicit combination of forecast probability, anomaly evidence, "
            "and persistence-informed ranking, as well as the decision to document each transformation path from API ingestion to analyst-facing output."
        )
    ],
    "1.3 Research Question and Objectives": [
        (
            "For the research question to be answerable at MSc standard, each objective requires an observable success criterion and a bounded failure "
            "criterion. Reproducibility is evidenced if reruns generate the same artefact schema and logically consistent metrics under unchanged source "
            "conditions. Forecasting quality is evidenced not only by high aggregate scores, but by coherent trade-offs across precision, recall, and "
            "ranked hit rate under fixed temporal splits. Anomaly utility is evidenced if alerts capture meaningful departures at a rate that is "
            "operationally tolerable, even if perfect overlap is unattainable in sparse-event settings. Interpretability is evidenced when each ranked "
            "output can be traced to decomposable components rather than opaque scalar scores. Governance compatibility is evidenced when scope limits, "
            "assumptions, and caveats are explicit enough that downstream users can avoid overclaiming what the model can do. This objective structure "
            "is important because it reduces retrospective narrative bias. Without explicit criteria, dissertation discussion can drift into selective "
            "emphasis on favourable metrics while underreporting fragile components. By contrast, objective-wise criteria create a clearer basis for "
            "critical judgement: some objectives may be strongly achieved, some partially achieved, and some dependent on future validation. That "
            "granularity supports a more credible research conclusion than an all-or-nothing success claim."
        )
    ],
    "1.4 Expected Outcomes and Scope": [
        (
            "An additional scope clarification concerns the interpretation of 'decision support'. In this dissertation, decision support means structured "
            "prioritisation assistance for human teams, not automated command execution. Outputs are intended to inform planning conversations, patrol "
            "allocation options, and analyst attention management. They are not intended to mandate action in the absence of contextual judgement. "
            "This distinction matters for both ethics and validity. A tool that supports prioritisation can be evaluated for ranking quality, stability, "
            "and explanatory adequacy; a tool that autonomously directs enforcement would require substantially stronger legal, procedural, and causal "
            "evidence than is feasible within an open-data MSc project. Scope is also bounded geographically and temporally: the configured area and "
            "monthly horizon provide a controlled test bed, but do not establish universal behavior across force areas, offence mixes, or policy regimes. "
            "Finally, expected outcomes include methodological transparency as a first-class deliverable. In practical dissertation terms, this means "
            "providing enough detail that another researcher can replicate the full transformation path, challenge the assumptions, and test alternative "
            "settings. A result that cannot be interrogated is not a strong academic outcome, even if the headline metric appears strong."
        )
    ],
    "2.1 Spatio-Temporal Hotspot Modelling Foundations": [
        (
            "Foundational work also highlights that spatial concentration should not be interpreted as static spatial destiny. Micro-locations can remain "
            "chronically high-risk while their internal composition changes, for example shifting from opportunistic theft peaks to disorder-related spikes "
            "under different activity regimes. This distinction between structural concentration and compositional volatility is central for model design. "
            "If features only encode absolute counts, models may miss meaningful transitions in local pressure patterns; if features only encode recent "
            "changes, models may overreact to short-lived noise. A robust foundation therefore requires both long-memory and short-memory representations, "
            "as well as neighborhood context to capture spillover and diffusion effects. Another important methodological issue concerns spatial unit choice. "
            "Administrative boundaries are easy to communicate but can blur micro-level hotspots through aggregation; fine grids improve local sensitivity "
            "but can increase sparsity and variance. The selected grid strategy in this study reflects a compromise: sufficient granularity to preserve "
            "street-level variation, with engineered smoothing through rolling and spatial lag features to stabilise inference. This balanced approach is "
            "consistent with the literature's broader lesson that hotspot prediction quality is not only about model class, but about the representational "
            "geometry of the problem itself."
        )
    ],
    "2.2 Forecasting Models for Crime Risk": [
        (
            "A critical reading of comparative forecasting studies suggests that reported gains are frequently shaped by evaluation decisions rather than "
            "architecture alone. For instance, models that appear superior under random folds may lose advantage when temporal ordering is enforced. "
            "Similarly, models with stronger recall at one threshold may produce unmanageable false-positive burden under realistic staffing constraints. "
            "Accordingly, this dissertation treats threshold policy as part of model behavior, not a post-processing afterthought. Another recurrent issue "
            "in the literature is the underreporting of failure modes. High-level metrics can mask systematic blind spots, such as under-detection in lower-"
            "volume cells or overprediction in persistent commercial zones. For operational systems, understanding these biases is as important as maximizing "
            "mean accuracy. Finally, model parsimony remains relevant. High-capacity deep and graph models can deliver incremental lift, but their deployment "
            "costs include longer retraining cycles, higher infrastructure demands, and reduced explanation accessibility for non-technical stakeholders. "
            "Within a public-facing, reproducible MSc context, a carefully tuned mixed family (RF, XGB, LSTM, plus interpretable baselines) offers a "
            "defensible balance between predictive performance and practical maintainability."
        )
    ],
    "2.3 Anomaly Intelligence in Urban Event Streams": [
        (
            "The anomaly literature further distinguishes three useful concepts: point anomalies (single unusual observations), contextual anomalies "
            "(observations unusual given local context), and collective anomalies (sequences that are jointly unusual). Crime operations frequently care "
            "most about contextual and collective anomalies, because isolated spikes may reflect reporting artifacts or one-off disruptions, while sustained "
            "deviations are more likely to indicate evolving pressure. This conceptual distinction justifies persistence-aware alert logic in the present "
            "study. It also explains why anomaly precision can remain modest even when the module is operationally useful: strict event-level labels are "
            "hard to define in aggregated monthly data, and many borderline cases occupy a gray zone between legitimate concern and statistical fluctuation. "
            "Another insight from anomaly research is the value of score decomposition. Composite anomaly signals are more actionable when analysts can inspect "
            "their components, such as residual magnitude, local robust scale, and isolation-based rarity. This transparency supports calibration dialogue: "
            "teams can revise thresholds with evidence rather than intuition. In sum, anomaly intelligence should be judged as an uncertainty-aware escalation "
            "aid, not a binary truth oracle."
        )
    ],
    "2.4 Critical Synthesis and Research Gap": [
        (
            "The synthesis can be sharpened into a specific research gap statement: there is limited publicly reproducible evidence on integrated, monthly "
            "area-level pipelines that jointly optimise hotspot foresight, anomaly awareness, and explainable ranking under documented governance constraints. "
            "Many studies provide strong methodological components, but fewer deliver end-to-end artefacts that can be rerun with current data, audited by "
            "non-authors, and interpreted by operational users without specialist tooling. This gap is not trivial. In applied domains, the absence of "
            "reproducible integration can delay institutional learning, because teams cannot easily test whether observed gains persist when data currency, "
            "threshold policy, or local conditions change. The contribution of this dissertation is therefore integrative: it combines established modelling "
            "techniques with explicit operational framing, rather than claiming novelty from algorithm invention alone. This orientation is academically "
            "valuable because it addresses translation risk between research publication and real decision settings. It also clarifies where future work is "
            "needed: broader external validation, richer exogenous features, and stronger human-centred evaluation of alert usefulness."
        )
    ],
    "3.1 Research Design and Data Strategy": [
        (
            "From a methodological governance perspective, the data strategy follows a provenance-first principle. Each monthly pull is treated as a dated "
            "snapshot of what would have been knowable at that time from the public source, rather than as a timeless historical truth. This distinction "
            "supports defensible interpretation when publication lags are present. The design also anticipates common reproducibility failures by keeping "
            "data transformation deterministic: explicit filtering rules, explicit deduplication logic, explicit feature lists, and persisted outputs at each "
            "stage. In addition, the study separates retrieval concerns from modelling concerns. API access, retry behaviour, and month window logic are "
            "defined independently so that model experimentation does not silently alter source assumptions. This separation improves maintainability and "
            "reduces hidden coupling errors in iterative development. Finally, the chosen temporal split is justified not only statistically but operationally. "
            "A model that performs well under chronological holdout better approximates prospective use than one evaluated on shuffled observations. The "
            "research design therefore aligns technical validity with anticipated deployment reality, which is a core requirement for high-quality applied "
            "dissertation work."
        )
    ],
    "3.2 Data Preparation and Feature Construction": [
        (
            "Data preparation includes several quality-control decisions that materially influence downstream inference. First, missing geolocation records are "
            "excluded because spatial assignment is central to the task; retaining them would inject label noise into grid-level counts. Second, incident "
            "identity deduplication is applied to reduce repeated-report distortion. Third, month strings are normalised and ordered before panel expansion, "
            "preventing accidental lexical rather than temporal sorting. The feature stack itself is designed as a complementary bundle: lag terms capture "
            "short memory, rolling terms capture trend and volatility, cyclic terms encode periodicity, and spatial lag terms encode neighborhood context. "
            "Persistence features then bridge these components by expressing whether current pressure is episodic or sustained. Importantly, feature "
            "construction is performed before split filtering where appropriate, but scaling and model fitting are performed after splitting to avoid leakage. "
            "This sequence maintains temporal integrity while preserving comparable feature definitions across train, validation, and test partitions. "
            "Collectively, these choices reflect the principle that feature engineering in spatio-temporal crime modelling is not cosmetic preprocessing; it "
            "is the primary representation layer through which the model can distinguish recurring structure from short-lived noise."
        )
    ],
    "3.3 Hotspot Forecasting Modelling": [
        (
            "Model configuration choices were guided by a bias-variance and interpretability trade-off rather than by exhaustive hyperparameter search. "
            "Random Forest depth and leaf constraints were selected to preserve nonlinear capacity while limiting brittle partitions. XGBoost settings were "
            "chosen for stable convergence under moderate imbalance, with conservative learning rate and subsampling to reduce overfit risk. LSTM structure "
            "was intentionally compact, reflecting the limited monthly sequence length and the desire to avoid parameter inflation relative to sample size. "
            "Early stopping on validation AUC provides an explicit safeguard against overtraining, and class weighting addresses asymmetric misclassification "
            "cost without synthetic resampling artifacts. The study also treats threshold selection as part of model design: classification quality depends on "
            "where decision boundaries are set, and these boundaries should be optimized against operationally relevant criteria. The inclusion of equal-weight "
            "and searched blends serves a diagnostic role, revealing whether complementary error profiles can improve ranking. However, restricting final "
            "reporting selection to the predefined methodology family prevents retrospective cherry-picking and strengthens research integrity."
        )
    ],
    "3.4 Anomaly Detection and Risk Fusion": [
        (
            "The anomaly and fusion layer is constructed to separate signal generation from decision policy. Signal generation produces residuals, robust z-score "
            "components, isolation rarity, and confidence terms. Decision policy then combines these signals with explicit weights and quantile rules. This "
            "separation is useful because policy tuning can be revised without rebuilding the full modelling stack, supporting controlled governance adaptation. "
            "The selected weights give primacy to hotspot probability while preserving meaningful influence from anomaly indicators and persistence. Although "
            "weighting is heuristic, it is transparent and auditable, which is preferable to hidden nonlinear blending in operational contexts requiring "
            "justification. The persistence gate is particularly important: without it, one-month residual shocks can dominate ranking and inflate low-value "
            "alerts. With persistence, alerts are biased toward sustained concern, accepting some recall loss in exchange for reduced volatility. The methodology "
            "therefore operationalises a clear philosophical stance: the system should prioritise stable actionable risk over maximal raw sensitivity when those "
            "goals conflict."
        )
    ],
    "3.5 Evaluation and Reproducibility Protocol": [
        (
            "Evaluation quality depends on whether metrics are interpreted in the context of decision constraints. Accuracy and AUC provide global discrimination "
            "signals, but operational planning often hinges on precision at the top of the ranking and month-to-month stability of selected areas. For this reason, "
            "the protocol includes backtesting and top-k hit analysis. Another important element is artefact-level reproducibility. Tables and figures are "
            "persisted to fixed output paths so that chapter narratives can be verified against machine-generated evidence. This avoids the common dissertation "
            "risk where narrative claims and latest outputs diverge after iterative reruns. The protocol also supports rerun auditability through metadata capture "
            "of execution date, latest published data month, and publication lag. These details make temporal claims falsifiable and prevent unintentional "
            "misrepresentation of data currency. While full computational reproducibility also depends on environment consistency, explicit dependency declaration "
            "and script-based execution materially reduce replication friction."
        )
    ],
    "3.6 System Architecture": [
        (
            "Architecturally, the system follows a pipeline-with-checkpoints pattern rather than a monolithic notebook pattern. Each stage has a bounded "
            "responsibility: retrieval, transformation, modelling, fusion, artefact generation, and presentation. Checkpoints improve robustness because failures "
            "can be diagnosed at stage boundaries and corrected without rerunning unrelated components. This is particularly useful when API retrieval latency and "
            "model training time differ. The dashboard orchestration layer deliberately invokes the pipeline as a subprocess, preserving reproducibility by ensuring "
            "that UI-triggered runs and command-line runs share the same implementation path. Another architectural strength is semantic continuity of identifiers: "
            "cell IDs and target months are preserved across tables, maps, and predictions, enabling traceable cross-view analysis. This continuity supports "
            "human review workflows, where an analyst may identify an unusual area on a map and verify its numeric evidence in tabular outputs. In research terms, "
            "the architecture demonstrates that explainability is not only a model property but also a system design property."
        )
    ],
    "4.1 Experimental Setup, Data Provenance, and Reproducibility": [
        (
            "To interpret the results rigorously, setup assumptions must be made explicit. The run represents a single reproducible snapshot under source conditions "
            "available on the execution date, not a claim of invariance across all future updates. Because the source data is periodically revised by publication "
            "cycles, absolute metrics may shift slightly in later reruns even when code is unchanged. What matters methodologically is whether relative behavior, "
            "error patterns, and ranking stability remain coherent under the same protocol. Another setup consideration is class definition by training quantile. "
            "This keeps labels adaptive to local intensity but means that hotspot prevalence is policy-relative rather than universal. Results should therefore be "
            "read as evidence of effective relative prioritisation within the defined system, not as an ontological boundary between safe and unsafe space. "
            "Reproducibility checks in this dissertation include regeneration of all tabular metrics, regeneration of figure artefacts, and consistency between "
            "script and notebook pathways. These checks strengthen confidence that reported findings reflect implemented logic rather than manual post-processing."
        )
    ],
    "4.2 Dataset Profile and Spatio-Temporal Behaviour": [
        (
            "The descriptive profile indicates a long-tailed spatial distribution in which a minority of cells dominate activity volume, especially in theft-linked "
            "categories. This has two direct modelling implications. First, high-volume cells provide richer temporal signal and may be easier to classify, which can "
            "inflate aggregate metrics if not complemented by localized error review. Second, lower-volume cells are more vulnerable to proportional volatility, where "
            "small count changes produce large relative shifts. The decreasing monthly mean across the test window suggests seasonal or contextual dampening, but the "
            "persistence of high-risk ranks implies that structural hotspots remain prominent despite volume decline. This combination of structural stability and "
            "level variation is precisely the pattern a practical forecasting system should handle. Spatial extent also matters: dense urban activity corridors can "
            "create adjacency cascades where pressure shifts one cell at a time. The inclusion of spatial lag and persistence features appears consistent with this "
            "behavioral geometry, supporting the view that observed performance is not accidental but representationally grounded."
        )
    ],
    "4.3 Model Performance and Threshold Behaviour": [
        (
            "A deeper reading of model behavior shows that discrimination quality and decision utility are related but not identical. A model can maintain high AUC "
            "while still producing an operationally awkward precision-recall profile at the chosen threshold. In this study, the selected model prioritises precision "
            "stability, resulting in relatively few false positives and a manageable analyst burden, but with a measurable false-negative tail. Error distribution "
            "suggests that missed hotspots often occur in cells with mixed historical trajectories, where recent decline masks rebound risk. This pattern is common in "
            "urban theft environments and indicates an opportunity for richer short-term momentum features or adaptive thresholding by local volatility class. "
            "Comparative results also illustrate that higher recall alternatives can be obtained, but usually with substantially more false positives. The key academic "
            "interpretation is that no metric should be judged in isolation. Threshold policy should be treated as an explicit governance choice linked to intervention "
            "capacity, not as a purely technical optimization problem."
        )
    ],
    "4.4 Backtesting, Spatial Validation, and Forecast Outputs": [
        (
            "Backtesting results are especially informative because they expose temporal robustness under realistic sequential prediction. Stable top-k hit rate across "
            "months indicates that the ranking mechanism is consistently identifying the most consequential areas, even when absolute hotspot counts fluctuate. "
            "However, month-level precision and recall movement also shows that score calibration is not perfectly stationary; local shifts in activity composition can "
            "change where the fixed threshold sits relative to the score distribution. This is a practical argument for periodic threshold review rather than one-time "
            "locking. Spatial map artefacts complement numeric tables by revealing whether errors are randomly dispersed or geographically clustered. Clustered misses "
            "may indicate systematic underrepresentation of specific local dynamics, while dispersed misses may reflect irreducible noise. Forecast output concentration "
            "in theft-dominant cells aligns with observed category prevalence, but it also raises operational caution: high-confidence recurrence zones can crowd out "
            "attention to emerging moderate-risk zones unless rank review criteria include exploratory allocation. In practice, a mixed strategy that reserves part of "
            "patrol capacity for emergent signals can improve resilience."
        )
    ],
    "4.5 Anomaly Intelligence Evaluation and Operational Meaning": [
        (
            "Anomaly metrics should be interpreted against the intrinsic ambiguity of monthly anomaly labeling. Unlike supervised hotspot labels, anomaly truth is "
            "partly constructed through robust statistical rules, which means borderline cases can be operationally significant yet counted as false positives under "
            "strict thresholds. This does not remove the need for improvement, but it reframes what improvement means. The objective is not merely to increase "
            "mathematical agreement with synthetic labels; it is to improve practical detection of meaningful escalations while controlling alert burden. The current "
            "results suggest that the module is useful as a prioritisation modifier, especially when interpreted alongside hotspot probability and residual context. "
            "Future refinements should focus on calibration and segmentation: different crime-type regimes may require different anomaly baselines, and persistence "
            "rules may benefit from adaptive windows in cells with known episodic patterns. Importantly, anomaly outputs already provide a richer evidential narrative "
            "than binary hotspot flags alone, which supports better human judgement under uncertainty."
        )
    ],
    "4.6 Critical Interpretation Against the Research Objectives": [
        (
            "A stronger critical interpretation distinguishes between technical completion and evidential sufficiency. Technical completion was achieved for all planned "
            "modules: ingestion, forecasting, anomaly scoring, fusion, and interface delivery. Evidential sufficiency is stronger for hotspot forecasting than for "
            "anomaly discrimination, primarily because hotspot labels are directly supervised while anomaly labels are proxy-based. This asymmetry does not weaken the "
            "dissertation; rather, it clarifies the maturity profile of the system. Forecasting can support operational pilot discussion now, whereas anomaly logic "
            "should be framed as a calibrated triage aid pending further validation with practitioner-reviewed escalation records. Another critical point is claim "
            "discipline. The results support improved prioritisation relative to static approaches within the defined context; they do not support deterministic claims "
            "about crime occurrence or causal claims about prevention outcomes. Maintaining this distinction is central to academic credibility and responsible use."
        )
    ],
    "5.1 Objective-wise Discussion and Research Question Closure": [
        (
            "Objective-wise closure can be strengthened by assigning confidence levels to each objective based on evidence quality. High confidence applies where "
            "evidence is direct, repeatable, and multi-source, as in reproducibility and model comparison outputs. Moderate confidence applies where evidence is "
            "positive but sensitive to policy settings, as in threshold-dependent ranking behavior. Developmental confidence applies where evidence is promising yet "
            "label-dependent, as in anomaly precision-recall outcomes. This confidence framing helps prevent overgeneralization and provides a structured bridge to "
            "future work. In relation to the research question, the central proposition is supported: an integrated framework can improve anticipatory prioritisation "
            "under constrained public-data conditions. The qualifier is implementation governance. Performance gains are most defensible when accompanied by explicit "
            "scope limits, periodic recalibration, and transparent analyst review protocols. This nuanced closure aligns with the dissertation's methodological stance "
            "that practical value emerges from systems coherence rather than isolated model scores."
        )
    ],
    "5.2 Practical Implications for Urban Safety Operations": [
        (
            "Operationally, the study suggests a pragmatic adoption pathway. First, use the ranked output as a briefing aid rather than an enforcement directive. "
            "Second, pair top-ranked zones with concise rationale fields so supervisors can challenge or endorse recommendations transparently. Third, monitor month-"
            "to-month alert volume and false-positive burden as explicitly as headline accuracy. This prevents gradual trust erosion that can occur when models are "
            "perceived as noisy or opaque. The findings also support a tiered deployment model: a core list for high-confidence recurrent hotspots and a secondary "
            "watch list for emerging anomalies. Such tiering preserves focus while maintaining exploratory capacity. Another implication is institutional learning. "
            "Because outputs are reproducible and archived, teams can retrospectively evaluate whether model-supported priorities aligned with later incident patterns, "
            "supporting iterative policy refinement. In short, the system's practical value lies not only in prediction but in creating a disciplined decision cycle "
            "where evidence, judgement, and accountability remain visible."
        )
    ],
    "5.3 Limitations and Validity Boundaries": [
        (
            "A rigorous limitations discussion should separate boundary conditions from errors. Boundary conditions are design choices consistent with project scope, "
            "such as area-level analysis and monthly horizon. Errors are avoidable weaknesses, such as potential calibration drift or insufficient anomaly label "
            "specificity. This distinction helps prioritize improvement effort. External validity remains a primary boundary: findings may not transfer unchanged to "
            "different urban morphologies or reporting cultures. Temporal validity is another boundary: publication lag means outputs inform near-term planning based "
            "on the latest available month, not immediate real-time operations. Label validity is a mixed case: hotspot labels are structured and reproducible, while "
            "anomaly labels are proxy-driven and therefore less definitive. Recognizing these validity layers improves interpretive discipline and prevents metric "
            "overreach. Importantly, none of these limitations negate the study's contribution; they specify where confidence is strongest and where additional evidence "
            "is required before broader deployment claims are warranted."
        )
    ],
    "5.4 Ethical and Operational Considerations": [
        (
            "Ethical quality in predictive public-safety systems requires more than privacy protection; it requires procedural fairness in how model outputs are used. "
            "Even with anonymised area-level data, concentrated deployment in repeatedly flagged zones can produce cumulative social effects if not periodically audited. "
            "Accordingly, governance should include proportionality checks, override logging, and transparent criteria for when model suggestions are accepted, deferred, "
            "or rejected. Another essential safeguard is role clarity: analysts interpret, supervisors decide, and model outputs remain advisory. This role separation "
            "reduces automation bias and preserves accountability pathways. Communication is equally important. Stakeholders should be informed that model scores express "
            "relative risk under defined assumptions, not certainty about individuals or inevitable outcomes. A mature governance posture therefore combines technical "
            "monitoring with procedural controls and public-facing transparency where possible. Such integration aligns the system with contemporary risk-management "
            "principles and supports legitimate, accountable use."
        )
    ],
    "5.5 Future Work Roadmap": [
        (
            "The roadmap can be operationalised through measurable milestones. In the short term, implement calibration diagnostics and threshold scenario testing, "
            "including workload-aware trade-off curves that link alert volume to expected precision. In the medium term, expand external validation across additional "
            "geographies and introduce exogenous covariates with documented provenance and sensitivity analysis. In parallel, develop an analyst feedback loop that "
            "captures whether alerts were judged useful, enabling supervised refinement of anomaly logic. In the longer term, integrate model governance artefacts: "
            "versioned model cards, drift reports, incident review logs, and formal change-control records. Importantly, future model complexity should be justified by "
            "net decision benefit, not by architectural novelty alone. Any adoption of graph or multi-scale deep models should include side-by-side comparisons on "
            "interpretability burden, retraining cost, and error explainability, ensuring that added complexity produces measurable operational value."
        )
    ],
    "5.6 Final Conclusion": [
        (
            "The final conclusion can be stated with precision: under documented UK open-data constraints, an integrated spatio-temporal pipeline can deliver strong "
            "area-level hotspot prioritisation and meaningful anomaly-aware augmentation when evaluated with strict temporal integrity. The strongest evidence concerns "
            "forecast ranking stability and reproducible artefact generation. The most developmental area concerns anomaly calibration under proxy labels. These results "
            "justify cautious advancement toward operational pilot discussions, provided governance controls remain explicit and human judgement remains central. The "
            "dissertation's academic contribution lies in demonstrating how methodological transparency, system integration, and critical claim discipline can be "
            "combined in applied AI research. Rather than presenting predictive performance as a standalone endpoint, the study presents it as one component in a broader "
            "decision-quality framework."
        )
    ],
    "5.7 Strategic Consolidation and Closing Reflection": [
        (
            "A strategic reflection from this work is that durable value in applied predictive systems depends on institutional learning capacity as much as on model "
            "accuracy. Systems that expose their assumptions, preserve traceable outputs, and support reasoned disagreement are more likely to improve over time than "
            "systems that deliver opaque scores with no audit trail. This dissertation has attempted to build in that learning capacity by making each stage inspectable "
            "and by presenting results with explicit boundaries. The broader lesson for academic practice is similar: high standards are served not by maximal claims, "
            "but by coherent methods, transparent evidence, and honest articulation of uncertainty. On that basis, the project offers a credible platform for continued "
            "research and measured operational exploration."
        )
    ],
}


def main() -> None:
    if not DOC_PATH.exists():
        raise FileNotFoundError(f"Document not found: {DOC_PATH}")

    doc = Document(DOC_PATH)

    # Locate heading paragraphs by exact text.
    heading_lookup: dict[str, Paragraph] = {}
    for para in doc.paragraphs:
        if para.style.name == "Heading 2":
            t = para.text.strip()
            if t in EXPANSIONS:
                heading_lookup[t] = para

    missing = [k for k in EXPANSIONS.keys() if k not in heading_lookup]
    if missing:
        raise RuntimeError(f"Missing headings in document: {missing}")

    # Insert expansions after each target heading, preserving existing styles/layout.
    for heading in EXPANSIONS.keys():
        anchor = heading_lookup[heading]
        cursor = anchor
        for block in EXPANSIONS[heading]:
            cursor = insert_paragraph_after(cursor, block, style="Normal")

    # Safety cleanup: remove prohibited names if present.
    for para in doc.paragraphs:
        para.text = re.sub(r"\bYagna\b", "the study", para.text, flags=re.IGNORECASE)
        para.text = re.sub(r"\bKarthik\b", "the study", para.text, flags=re.IGNORECASE)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    para.text = re.sub(r"\bYagna\b", "the study", para.text, flags=re.IGNORECASE)
                    para.text = re.sub(r"\bKarthik\b", "the study", para.text, flags=re.IGNORECASE)

    doc.save(DOC_PATH)

    # Reopen and report checks.
    final_doc = Document(DOC_PATH)
    wc = word_count_excluding_references(final_doc)
    duplicates = duplicate_long_paragraphs(final_doc)
    print(f"Saved: {DOC_PATH}")
    print(f"Word count excluding references: {wc}")
    print(f"Repeated long paragraphs (>120 chars): {len(duplicates)}")
    for n, t in duplicates[:10]:
        print(f"COUNT={n} | {t[:180]}")


if __name__ == "__main__":
    main()

