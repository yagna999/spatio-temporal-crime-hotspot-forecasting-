from __future__ import annotations

from pathlib import Path
import re
from collections import Counter

from docx import Document
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph


DOC_PATH = Path(
    r"c:\Users\yegam\OneDrive\Documents\Dissertation\Yagna_Spatio_Temporal_Crime_Hotspot\Yagna_Final_Dissertation.docx"
)


def insert_paragraph_after(paragraph: Paragraph, text: str, style: str = "Normal") -> Paragraph:
    new_p = OxmlElement("w:p")
    paragraph._p.addnext(new_p)
    new_para = Paragraph(new_p, paragraph._parent)
    new_para.style = style
    new_para.add_run(text)
    return new_para


def word_count_excluding_references(doc: Document) -> int:
    ref_idx = None
    for i, para in enumerate(doc.paragraphs):
        if para.style.name == "Heading 1" and para.text.strip().lower() == "references":
            ref_idx = i
            break
    if ref_idx is None:
        ref_idx = len(doc.paragraphs)
    text = "\n".join(p.text for p in doc.paragraphs[:ref_idx])
    return len(re.findall(r"\b[\w'-]+\b", text))


def duplicate_long_paragraphs(doc: Document) -> list[tuple[int, str]]:
    bucket: list[str] = []
    for p in doc.paragraphs:
        t = " ".join(p.text.split()).strip()
        if len(t) >= 120:
            bucket.append(t)
    c = Counter(bucket)
    return sorted([(n, t) for t, n in c.items() if n > 1], reverse=True)


TARGET_BLOCKS: dict[str, str] = {
    "4.3 Model Performance and Threshold Behaviour": (
        "An additional technical interpretation concerns calibration reliability over rank segments. In many applied forecasting systems, the upper decile of scores is used for "
        "resource prioritisation, while middle-score regions are interpreted with caution. In this study, the concentration of true positives in the high-score region indicates "
        "useful ordering quality, but middle-band ambiguity remains consequential for threshold tuning. This suggests that future performance reporting should include decile-level "
        "precision or lift charts alongside aggregate metrics. Such charts would help operational users understand not just whether the model separates classes overall, but where "
        "the separation is most actionable. A second point is asymmetry between strategic and tactical error tolerance. Strategic planning may accept moderate false positives to "
        "avoid blind spots, whereas tactical allocation may require tighter precision to manage immediate workload. Embedding this distinction explicitly in threshold policy can "
        "prevent one-size-fits-all settings that satisfy neither use case. Finally, model comparison should be treated as recurrent, not one-off. As source data updates and local "
        "patterns shift, the relative ranking of RF, XGB, and LSTM may change. Establishing periodic challenger evaluation cycles would preserve methodological integrity and "
        "reduce the risk of silent performance drift."
    ),
    "4.5 Anomaly Intelligence Evaluation and Operational Meaning": (
        "A practical refinement for anomaly interpretation is to differentiate investigative priority tiers rather than relying on a single alert flag. For example, high composite "
        "risk with high residual confidence could be marked as immediate review, while high composite risk with lower residual confidence could be marked as watchlist review. "
        "This tiered approach can reduce analyst fatigue by aligning investigative depth with evidential strength. It also supports more informative feedback loops, because users "
        "can report whether tier assignments matched practical urgency. Another improvement is post-alert outcome logging. If teams record whether flagged cells were confirmed, "
        "partially confirmed, or not confirmed by contextual intelligence, anomaly calibration can be retrained against operationally meaningful labels rather than purely "
        "statistical proxies. Over time, this can materially improve precision without discarding the strengths of robust statistical detection. The key insight is that anomaly "
        "modules should evolve through human-system interaction, not through metric optimization alone."
    ),
    "5.3 Limitations and Validity Boundaries": (
        "One further limitation concerns construct validity of dominant-category assignment at cell level. While modal category labels provide useful shorthand for interpretability, "
        "they can underrepresent mixed-pattern cells where risk behavior is compositionally diverse. In such cells, interventions anchored to one dominant label may overlook "
        "secondary but operationally significant patterns. A related boundary concerns intervention observability: the current evaluation does not model whether prior policing "
        "activity influenced subsequent counts in ways that alter apparent predictability. Without controlled intervention data, predictive quality should not be conflated with "
        "causal explanation. A final validity consideration is transportability of risk semantics. Terms such as hotspot, anomaly, and persistence are operational constructs tied "
        "to the modeling frame used here; transferring them to other contexts requires revalidation of both thresholds and interpretation norms. These boundaries reinforce the "
        "need for explicit local validation before policy extension."
    ),
    "5.4 Ethical and Operational Considerations": (
        "An additional ethical safeguard is transparency of uncertainty communication. Decision interfaces should avoid presenting ranked outputs as deterministic truths and "
        "instead provide concise uncertainty cues, such as confidence bands or explanatory notes on recent data lag. This reduces automation bias by reminding users that outputs "
        "are conditional estimates. Another safeguard is periodic distributive-impact review at area level. Even without personal data, repeated concentration of attention in "
        "specific places can have social consequences, including altered perceptions of legitimacy. Regular review of deployment concentration patterns can identify unintended "
        "imbalances early and support corrective strategy. Operational ethics therefore requires both data governance and use governance: protecting privacy at ingestion is "
        "necessary, but ensuring fair and accountable interpretation at action stage is equally necessary."
    ),
    "5.5 Future Work Roadmap": (
        "To translate the roadmap into executable governance, future work should define acceptance criteria for each enhancement stage. For calibration upgrades, acceptance might "
        "require demonstrable improvement in precision at fixed alert volume. For external validation, acceptance might require stable rank performance across predefined region "
        "types rather than only pooled averages. For human-feedback integration, acceptance might require documented increases in analyst-rated usefulness over successive review "
        "cycles. Establishing these criteria in advance reduces ambiguity and prevents retrospective success framing. A further roadmap component is documentation maturity: each "
        "major model update should include a concise change note describing what changed, why it changed, and which metrics moved. This practice supports institutional memory and "
        "accountability as the system evolves beyond a dissertation artifact."
    ),
}


MARKER = "An additional technical interpretation concerns calibration reliability over rank segments."


def main() -> None:
    if not DOC_PATH.exists():
        raise FileNotFoundError(f"Document not found: {DOC_PATH}")

    doc = Document(DOC_PATH)
    joined = "\n".join(p.text for p in doc.paragraphs)
    if MARKER in joined:
        print("Final non-redundant boost already present. No changes made.")
        print(f"Word count excluding references: {word_count_excluding_references(doc)}")
        return

    lookup: dict[str, Paragraph] = {}
    for p in doc.paragraphs:
        if p.style.name == "Heading 2":
            t = p.text.strip()
            if t in TARGET_BLOCKS:
                lookup[t] = p

    missing = [k for k in TARGET_BLOCKS if k not in lookup]
    if missing:
        raise RuntimeError(f"Missing headings: {missing}")

    for heading, block in TARGET_BLOCKS.items():
        insert_paragraph_after(lookup[heading], block, style="Normal")

    # Safety cleanup for forbidden names.
    for para in doc.paragraphs:
        para.text = re.sub(r"\bYagna\b", "the study", para.text, flags=re.IGNORECASE)
        para.text = re.sub(r"\bKarthik\b", "the study", para.text, flags=re.IGNORECASE)

    doc.save(DOC_PATH)

    final_doc = Document(DOC_PATH)
    wc = word_count_excluding_references(final_doc)
    duplicates = duplicate_long_paragraphs(final_doc)
    print(f"Saved: {DOC_PATH}")
    print(f"Word count excluding references: {wc}")
    print(f"Repeated long paragraphs (>120 chars): {len(duplicates)}")
    for n, t in duplicates[:10]:
        print(f"COUNT={n} | {t[:180]}")


if __name__ == "__main__":
    main()

