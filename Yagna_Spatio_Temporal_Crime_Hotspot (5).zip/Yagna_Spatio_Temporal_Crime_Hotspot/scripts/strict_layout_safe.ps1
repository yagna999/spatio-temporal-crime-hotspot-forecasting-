$ErrorActionPreference = "Stop"

$docPath = "c:\Users\yegam\OneDrive\Documents\Dissertation\Yagna_Spatio_Temporal_Crime_Hotspot\Yagna_Final_Dissertation.docx"
$backupPath = "c:\Users\yegam\OneDrive\Documents\Dissertation\Yagna_Spatio_Temporal_Crime_Hotspot\Yagna_Final_Dissertation_before_strict_layout_safe.docx"

$wdAlignParagraphLeft = 0
$wdAlignParagraphCenter = 1
$wdAlignParagraphJustify = 3
$wdLineSpace1pt5 = 1
$wdFindContinue = 1
$wdReplaceAll = 2
$wdPageNumber = 1

function Clean-ParaText([string]$t) {
    if ($null -eq $t) { return "" }
    return (($t -replace "[`r`a]", "") -replace "\s+", " ").Trim()
}

function Get-Heading1Map($doc) {
    $map = @{}
    for ($i = 1; $i -le $doc.Paragraphs.Count; $i++) {
        $p = $doc.Paragraphs.Item($i)
        $styleName = $p.Range.Style.NameLocal
        $txt = Clean-ParaText $p.Range.Text
        if ($styleName -eq "Heading 1" -and $txt -ne "" -and -not $map.ContainsKey($txt)) {
            $map[$txt] = $i
        }
    }
    return $map
}

function Get-NextHeading1Index($doc, [int]$index) {
    for ($i = $index + 1; $i -le $doc.Paragraphs.Count; $i++) {
        $p = $doc.Paragraphs.Item($i)
        if ($p.Range.Style.NameLocal -eq "Heading 1") {
            return $i
        }
    }
    return $null
}

function Move-Heading1BlockBefore($doc, [string]$headingToMove, [string]$targetHeading) {
    $map = Get-Heading1Map $doc
    if (-not $map.ContainsKey($headingToMove)) {
        throw "Heading not found: $headingToMove"
    }
    if (-not $map.ContainsKey($targetHeading)) {
        throw "Target heading not found: $targetHeading"
    }

    $moveIdx = [int]$map[$headingToMove]
    $nextMove = Get-NextHeading1Index $doc $moveIdx
    $moveStart = $doc.Paragraphs.Item($moveIdx).Range.Start
    $moveEnd = if ($null -ne $nextMove) { $doc.Paragraphs.Item($nextMove).Range.Start } else { $doc.Content.End }
    $moveRange = $doc.Range($moveStart, $moveEnd)
    $moveRange.Cut() | Out-Null

    # Resolve target after cut and paste at target.
    $map3 = Get-Heading1Map $doc
    if (-not $map3.ContainsKey($targetHeading)) {
        throw "Target heading disappeared after cut: $targetHeading"
    }
    $targetStart2 = $doc.Paragraphs.Item([int]$map3[$targetHeading]).Range.Start
    $insertRange = $doc.Range($targetStart2, $targetStart2)
    $insertRange.Paste() | Out-Null
}

function Set-PageBreakBeforeHeading($doc, [string]$headingText, [bool]$value) {
    $map = Get-Heading1Map $doc
    if (-not $map.ContainsKey($headingText)) {
        throw "Heading not found for page-break: $headingText"
    }
    [void]($doc.Paragraphs.Item([int]$map[$headingText]).Format.PageBreakBefore = $value)
}

function Clear-SectionBodyByHeading($doc, [string]$headingText) {
    $map = Get-Heading1Map $doc
    if (-not $map.ContainsKey($headingText)) {
        throw "Heading not found for section clear: $headingText"
    }
    $idx = [int]$map[$headingText]
    $nextIdx = Get-NextHeading1Index $doc $idx
    if ($null -eq $nextIdx) { return }
    $start = $doc.Paragraphs.Item($idx).Range.End
    $end = $doc.Paragraphs.Item($nextIdx).Range.Start
    if ($end -gt $start) {
        $doc.Range($start, $end).Delete()
    }
}

function Insert-TOCAtHeading($doc, [string]$headingText) {
    $map = Get-Heading1Map $doc
    if (-not $map.ContainsKey($headingText)) {
        throw "Heading not found for TOC insert: $headingText"
    }
    $idx = [int]$map[$headingText]
    $insertPos = $doc.Paragraphs.Item($idx).Range.End
    $rng = $doc.Range($insertPos, $insertPos)
    [void]$doc.TablesOfContents.Add($rng)
}

function Insert-TOFAtHeading($doc, [string]$headingText, [string]$label) {
    $map = Get-Heading1Map $doc
    if (-not $map.ContainsKey($headingText)) {
        throw "Heading not found for TOF insert: $headingText"
    }
    $idx = [int]$map[$headingText]
    $insertPos = $doc.Paragraphs.Item($idx).Range.End
    $rng = $doc.Range($insertPos, $insertPos)
    [void]$doc.TablesOfFigures.Add($rng, $label)
}

# File-level backup first.
Copy-Item -Path $docPath -Destination $backupPath -Force

$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0

try {
    $doc = $word.Documents.Open($docPath)

    # Ensure expected headings exist before any move.
    $h = Get-Heading1Map $doc
    foreach ($needed in @(
        "Abstract", "Acknowledgements", "Contents", "List of Figures",
        "List of Tables", "List of Acronyms", "Chapter 1 Introduction"
    )) {
        if (-not $h.ContainsKey($needed)) {
            throw "Required heading missing before layout fix: $needed"
        }
    }

    # Reorder front-matter sections.
    Move-Heading1BlockBefore $doc "Contents" "Abstract"
    Move-Heading1BlockBefore $doc "List of Figures" "List of Tables"
    Move-Heading1BlockBefore $doc "Abstract" "Chapter 1 Introduction"
    Move-Heading1BlockBefore $doc "Acknowledgements" "Chapter 1 Introduction"

    # Remove manual page breaks.
    $find = $doc.Content.Find
    $find.ClearFormatting()
    $find.Replacement.ClearFormatting()
    $find.Text = "^m"
    $find.Replacement.Text = ""
    [void]$find.Execute($find.Text, $false, $false, $false, $false, $false, $true, $wdFindContinue, $false, $find.Replacement.Text, $wdReplaceAll)

    # Base styles.
    $normal = $doc.Styles.Item("Normal")
    $normal.Font.Name = "Times New Roman"
    $normal.Font.Size = 12
    $normal.ParagraphFormat.Alignment = $wdAlignParagraphJustify
    $normal.ParagraphFormat.LineSpacingRule = $wdLineSpace1pt5
    $normal.ParagraphFormat.SpaceBefore = 0
    $normal.ParagraphFormat.SpaceAfter = 0

    try {
        $caption = $doc.Styles.Item("Caption")
        $caption.Font.Name = "Times New Roman"
        $caption.Font.Size = 12
        $caption.Font.Bold = 0
        $caption.ParagraphFormat.Alignment = $wdAlignParagraphCenter
        $caption.ParagraphFormat.LineSpacingRule = $wdLineSpace1pt5
        $caption.ParagraphFormat.SpaceBefore = 0
        $caption.ParagraphFormat.SpaceAfter = 0
    } catch {
    }

    foreach ($styleName in @("TOC 1", "TOC 2", "TOC 3", "TOC 4", "Table of Figures")) {
        try {
            $s = $doc.Styles.Item($styleName)
            $s.Font.Name = "Times New Roman"
            $s.Font.Size = 12
            $s.Font.Bold = 0
            $s.ParagraphFormat.Alignment = $wdAlignParagraphJustify
            $s.ParagraphFormat.LineSpacingRule = $wdLineSpace1pt5
            $s.ParagraphFormat.SpaceBefore = 0
            $s.ParagraphFormat.SpaceAfter = 0
        } catch {
        }
    }

    # Paragraph-level enforcement.
    for ($i = 1; $i -le $doc.Paragraphs.Count; $i++) {
        $p = $doc.Paragraphs.Item($i)
        $styleName = $p.Range.Style.NameLocal
        $txt = Clean-ParaText $p.Range.Text

        $p.Range.Font.Name = "Times New Roman"
        if ($styleName -notlike "Heading*") { $p.Range.Font.Size = 12 }

        $p.Format.LineSpacingRule = $wdLineSpace1pt5
        $p.Format.SpaceBefore = 0
        $p.Format.SpaceAfter = 0

        if ($styleName -eq "Caption" -or $txt -match "^(Figure|Table)\s+\d") {
            $p.Range.Font.Bold = 0
            $p.Format.Alignment = $wdAlignParagraphCenter
        } elseif ($styleName -notlike "Heading*") {
            $p.Format.Alignment = $wdAlignParagraphJustify
        }
    }

    # Page starts per requirement.
    Set-PageBreakBeforeHeading $doc "Contents" $true
    Set-PageBreakBeforeHeading $doc "List of Figures" $true
    Set-PageBreakBeforeHeading $doc "List of Tables" $true
    Set-PageBreakBeforeHeading $doc "List of Acronyms" $false
    Set-PageBreakBeforeHeading $doc "Abstract" $true
    Set-PageBreakBeforeHeading $doc "Acknowledgements" $true

    foreach ($ch in @(
        "Chapter 1 Introduction",
        "Chapter 2 Literature Review and Related Work",
        "Chapter 3 Methodology",
        "Chapter 4 Experimental Results and Discussion",
        "Chapter 5 Discussion, Conclusion, and Future Work",
        "References"
    )) {
        Set-PageBreakBeforeHeading $doc $ch $true
    }

    # Rebuild TOC / LOF / LOT to ensure page-number sync.
    if ($doc.TablesOfContents.Count -gt 0) {
        for ($i = $doc.TablesOfContents.Count; $i -ge 1; $i--) {
            $doc.TablesOfContents.Item($i).Delete()
        }
    }
    if ($doc.TablesOfFigures.Count -gt 0) {
        for ($i = $doc.TablesOfFigures.Count; $i -ge 1; $i--) {
            $doc.TablesOfFigures.Item($i).Delete()
        }
    }

    Clear-SectionBodyByHeading $doc "Contents"
    Clear-SectionBodyByHeading $doc "List of Figures"
    Clear-SectionBodyByHeading $doc "List of Tables"

    Insert-TOCAtHeading $doc "Contents"
    Insert-TOFAtHeading $doc "List of Figures" "Figure"
    Insert-TOFAtHeading $doc "List of Tables" "Table"

    # Repaginate and refresh fields.
    $doc.Repaginate()
    $doc.Fields.Update() | Out-Null
    if ($doc.TablesOfContents.Count -gt 0) {
        for ($i = 1; $i -le $doc.TablesOfContents.Count; $i++) {
            $doc.TablesOfContents.Item($i).Update()
        }
    }
    if ($doc.TablesOfFigures.Count -gt 0) {
        for ($i = 1; $i -le $doc.TablesOfFigures.Count; $i++) {
            $doc.TablesOfFigures.Item($i).Update()
        }
    }

    $doc.Save()
    $doc.Close()
} finally {
    $word.Quit()
}

Write-Output "Strict layout safe pass complete."
Write-Output "Document: $docPath"
Write-Output "Backup: $backupPath"
