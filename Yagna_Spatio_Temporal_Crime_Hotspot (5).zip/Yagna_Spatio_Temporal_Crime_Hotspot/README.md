﻿# Final Dissertation Implementation (API-Only)

This project now implements the full proposed system for a masters-level spatio-temporal crime hotspot dissertation.

## Final scope delivered

- API-only ingestion from UK Police API (no local JSON cache used for model training).
- End-to-end hotspot modeling with:
  - Random Forest
  - XGBoost
  - LSTM
  - Ensemble and super-ensemble fusion
- Full model comparison (accuracy, precision, recall, F1, AUC, threshold).
- Backtesting module with monthly validation graphs and hotspot hit-rate tracking.
- Anomaly intelligence with residual + MAD + IsolationForest + alert logic.
- Google-tile hotspot maps:
  - Real vs predicted hotspot backtest map
  - Next-month forecast hotspot map
- Local Streamlit UI and executed Jupyter notebook.

## Key files

- `scripts/prototype_pipeline.py` - final API-only modeling pipeline
- `app.py` - final local UI dashboard
- `notebooks/realtime_crime_hotspot_pipeline.ipynb` - final executed notebook
- `scripts/run_notebook.py` - notebook executor

## Outputs

- `outputs/metrics.json`
- `outputs/model_comparison.csv`
- `outputs/backtest_monthly_metrics.csv`
- `outputs/test_predictions.csv`
- `outputs/latest_anomaly_alerts.csv`
- `outputs/next_month_top_alerts.csv`
- `outputs/figures/*.png`
- `outputs/figures/backtest_hotspots_google_map.html`
- `outputs/figures/forecast_hotspots_google_map.html`

## Run

```powershell
python scripts/prototype_pipeline.py
python scripts/run_notebook.py
streamlit run app.py
```
