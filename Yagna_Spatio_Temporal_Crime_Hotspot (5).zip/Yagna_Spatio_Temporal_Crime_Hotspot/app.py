﻿import json
import subprocess
import sys
from pathlib import Path

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = ROOT / "outputs"
FIG_DIR = OUTPUT_DIR / "figures"
PIPELINE_SCRIPT = ROOT / "scripts" / "prototype_pipeline.py"

st.set_page_config(
    page_title="UK Crime Hotspot Intelligence",
    page_icon="M",
    layout="wide",
)

st.markdown(
    """
    <style>
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    [data-testid="stToolbar"] {display: none !important;}

    .stApp {
        background:
            radial-gradient(circle at 20% 20%, rgba(64, 78, 138, 0.36), transparent 38%),
            radial-gradient(circle at 84% 8%, rgba(127, 62, 114, 0.28), transparent 34%),
            linear-gradient(145deg, #0b1020 0%, #101730 48%, #0a1429 100%);
        color: #e8ecff;
    }

    .block-container {
        padding-top: 1.15rem;
        padding-bottom: 1.2rem;
    }

    .app-header {
        border: 1px solid rgba(140, 155, 255, 0.24);
        background: rgba(17, 24, 49, 0.72);
        border-radius: 14px;
        padding: 1rem 1.2rem;
        margin-bottom: 0.7rem;
        backdrop-filter: blur(4px);
    }

    .app-tip {
        border: 1px solid rgba(98, 123, 255, 0.35);
        background: rgba(39, 54, 102, 0.42);
        border-radius: 10px;
        padding: 0.55rem 0.75rem;
        color: #c8d4ff;
        font-size: 0.94rem;
        margin-top: 0.2rem;
    }

    .app-footer {
        border: 1px solid rgba(140, 155, 255, 0.20);
        background: rgba(16, 22, 44, 0.62);
        border-radius: 12px;
        padding: 0.8rem 1rem;
        margin-top: 1rem;
        color: #aab5e8;
        font-size: 0.92rem;
        text-align: center;
    }

    div[data-baseweb="tab-list"] {
        gap: 0.35rem;
        border-bottom: 1px solid rgba(150, 160, 220, 0.25);
    }

    button[data-baseweb="tab"] {
        background: rgba(28, 36, 72, 0.78) !important;
        border: 1px solid rgba(120, 140, 230, 0.35) !important;
        border-radius: 10px 10px 0 0 !important;
        color: #d7e0ff !important;
        padding: 0.45rem 0.8rem !important;
    }

    button[data-baseweb="tab"][aria-selected="true"] {
        background: linear-gradient(90deg, #3558ff, #607eff) !important;
        color: #ffffff !important;
        border-color: #6f88ff !important;
        font-weight: 600 !important;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


def run_pipeline() -> tuple[bool, str]:
    proc = subprocess.run(
        [sys.executable, str(PIPELINE_SCRIPT)],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    logs = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
    return proc.returncode == 0, logs


def load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def load_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path)


def load_outputs() -> tuple[dict, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    metrics = load_json(OUTPUT_DIR / "metrics.json")
    comparison = load_csv(OUTPUT_DIR / "model_comparison.csv")
    backtest = load_csv(OUTPUT_DIR / "backtest_monthly_metrics.csv")
    next_alerts = load_csv(OUTPUT_DIR / "next_month_top_alerts.csv")
    latest_anomalies = load_csv(OUTPUT_DIR / "latest_anomaly_alerts.csv")
    return metrics, comparison, backtest, next_alerts, latest_anomalies


def show_google_map(path: Path, title: str, height: int = 620):
    st.subheader(title)
    if not path.exists():
        st.info(f"Missing map file: {path.name}")
        return
    html = path.read_text(encoding="utf-8")
    components.html(html, height=height, scrolling=True)


def pretty_model_name(value: str) -> str:
    mapping = {
        "rf": "Random Forest",
        "xgb": "Extreme Gradient Boosting",
        "lstm": "Long Short-Term Memory Network",
        "ensemble": "Equal Weight Ensemble",
        "super_ensemble": "Optimized Super Ensemble",
        "baseline": "Historical Baseline",
    }
    return mapping.get(value, value)


def resolve_forecast_probability_column(df: pd.DataFrame) -> str:
    candidates = [
        "selected_model_prob",
        "super_ensemble_prob",
        "ensemble_prob",
        "rf_prob",
        "xgb_prob",
        "lstm_prob",
    ]
    for col in candidates:
        if col in df.columns:
            return col
    return "selected_model_prob"


st.markdown(
    """
    <div class="app-header">
      <h1 style="margin:0; color:#eef2ff;">Spatio-Temporal UK Crime Hotspot and Anomaly Intelligence</h1>
      <p style="margin:0.35rem 0 0 0; color:#b9c4ff;">
        Dark mode dashboard with API-powered hotspot analytics, map validation, and production-model forecasting.
      </p>
    </div>
    """,
    unsafe_allow_html=True,
)

metrics, comparison, backtest, next_alerts, latest_anomalies = load_outputs()
selected_model_name = pretty_model_name(metrics.get("selected_model_for_reporting", "ensemble"))
run_uk_date = metrics.get("run_uk_date", "N/A")
current_calendar_month = metrics.get("current_calendar_month", "N/A")
available_data_upto_month = metrics.get("available_data_upto_month", metrics.get("latest_api_month", "N/A"))
api_publication_lag_months = metrics.get("api_publication_lag_months", "N/A")

controls_left, controls_right = st.columns([1.2, 2.8])
with controls_left:
    run_clicked = st.button("Run Model and Refresh Data", type="primary", use_container_width=True)

with controls_right:
    st.markdown(
        "<div class='app-tip'>"
        f"Selected production model: <b>{selected_model_name}</b><br>"
        f"Run date (UK): <b>{run_uk_date}</b> | Current month: <b>{current_calendar_month}</b><br>"
        f"Data available up to: <b>{available_data_upto_month}</b> | Publication lag: <b>{api_publication_lag_months} month(s)</b><br>"
        "This dashboard follows the proposed-system core modules only (no place-search module)."
        "</div>",
        unsafe_allow_html=True,
    )

if run_clicked:
    with st.spinner("Running pipeline with latest API data..."):
        ok, logs = run_pipeline()
    if ok:
        st.success("Model run completed and data refreshed.")
    else:
        st.error("Model run failed. Check logs below.")
    with st.expander("Pipeline Logs", expanded=not ok):
        st.text(logs)

    metrics, comparison, backtest, next_alerts, latest_anomalies = load_outputs()

if not metrics:
    st.warning("No outputs found. Click 'Run Model and Refresh Data' to generate results.")
    st.stop()

selected_model_code = metrics.get("selected_model_for_reporting", "ensemble")
selected_model_name = pretty_model_name(selected_model_code)
run_uk_date = metrics.get("run_uk_date", "N/A")
current_calendar_month = metrics.get("current_calendar_month", "N/A")
available_data_upto_month = metrics.get("available_data_upto_month", metrics.get("latest_api_month", "N/A"))
api_publication_lag_months = metrics.get("api_publication_lag_months", "N/A")
forecast_prob_col = resolve_forecast_probability_column(next_alerts)
forecast_prob_label = f"{selected_model_name} Probability"

if "selected_model" in next_alerts.columns:
    next_alerts = next_alerts.copy()
    next_alerts["selected_model"] = next_alerts["selected_model"].map(pretty_model_name)

if "selected_model" in latest_anomalies.columns:
    latest_anomalies = latest_anomalies.copy()
    latest_anomalies["selected_model"] = latest_anomalies["selected_model"].map(pretty_model_name)

st.caption(
    f"Selected model: {selected_model_name} | Run date (UK): {run_uk_date} | "
    f"Current month: {current_calendar_month} | Data available up to: {available_data_upto_month} "
    f"(lag: {api_publication_lag_months} month(s))"
)

tabs = st.tabs(
    [
        "Model Comparison",
        "Backtesting",
        "Google Hotspot Maps",
        "Forecast Hotspot Records",
        "Anomaly Hotspot Records",
    ]
)

with tabs[0]:
    view = comparison.copy()
    if not view.empty:
        view["model"] = view["model"].map(pretty_model_name)
        view = view.rename(
            columns={
                "model": "Model",
                "threshold": "Decision Threshold",
                "val_accuracy": "Validation Accuracy",
                "val_f1": "Validation F1 Score",
                "accuracy": "Test Accuracy",
                "precision": "Test Precision",
                "recall": "Test Recall",
                "f1": "Test F1 Score",
                "auc": "Test Area Under ROC Curve",
                "tn": "True Negatives",
                "fp": "False Positives",
                "fn": "False Negatives",
                "tp": "True Positives",
            }
        )
    st.dataframe(view, use_container_width=True, height=430)

with tabs[1]:
    bt = backtest.rename(
        columns={
            "target_month": "Target Month",
            "accuracy": "Accuracy",
            "precision": "Precision",
            "recall": "Recall",
            "f1": "F1 Score",
            "predicted_hotspots": "Predicted Hotspot Count",
            "actual_hotspots": "Actual Hotspot Count",
            "top10_hit_rate": "Top 10 Hotspot Hit Rate",
        }
    )
    st.dataframe(bt, use_container_width=True, height=430)

with tabs[2]:
    show_google_map(
        FIG_DIR / "backtest_hotspots_google_map.html",
        "Backtesting Map: Real Hotspots vs Predicted Hotspots",
    )
    show_google_map(
        FIG_DIR / "forecast_hotspots_google_map.html",
        "Forecast Map: Next-Month High-Risk Hotspots",
    )

with tabs[3]:
    forecast_view = next_alerts.rename(
        columns={
            "cell_id": "Grid Cell Identifier",
            "hotspot_name": "Hotspot Location Name",
            "dominant_crime_type": "Dominant Crime Type",
            "month": "Forecast Input Month",
            "lat_center": "Latitude",
            "lon_center": "Longitude",
            "crime_count": "Current Crime Count",
            "lag1": "Previous Month Crime Count",
            forecast_prob_col: forecast_prob_label,
            "hotspot_persistence": "Hotspot Persistence Score",
            "selected_model": "Selected Prediction Model",
            "forecast_risk": "Forecast Risk Score",
        }
    )
    st.dataframe(forecast_view, use_container_width=True, height=430)

with tabs[4]:
    anomaly_view = latest_anomalies.rename(
        columns={
            "target_month": "Target Month",
            "cell_id": "Grid Cell Identifier",
            "hotspot_name": "Hotspot Location Name",
            "dominant_crime_type": "Dominant Crime Type",
            "selected_model": "Selected Prediction Model",
            "selected_prob": "Selected Model Probability",
            "selected_pred": "Selected Model Predicted Hotspot",
            "anomaly_score": "Anomaly Score",
            "composite_risk": "Composite Risk Score",
            "alert": "Anomaly Alert Flag",
            "true_anomaly": "Ground Truth Anomaly Flag",
        }
    )
    st.dataframe(anomaly_view, use_container_width=True, height=430)

st.markdown(
    """
    <div class="app-footer">
      MSc Dissertation System | Spatio-Temporal Crime Hotspot Forecasting and Anomaly Intelligence |
      Data source: UK Police API | Run command: python run_localhost.py
    </div>
    """,
    unsafe_allow_html=True,
)
