from __future__ import annotations

import argparse
import importlib
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path


ROOT = Path(__file__).resolve().parent
APP_FILE = ROOT / "app.py"
PIPELINE_FILE = ROOT / "scripts" / "prototype_pipeline.py"
REQUIRED_OUTPUTS = [
    ROOT / "outputs" / "metrics.json",
    ROOT / "outputs" / "model_comparison.csv",
    ROOT / "outputs" / "test_predictions.csv",
]


def port_is_open(host: str, port: int, timeout: float = 0.35) -> bool:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        return sock.connect_ex((host, port)) == 0
    finally:
        sock.close()


def check_modules() -> None:
    required_modules = ["streamlit", "pandas", "numpy"]
    missing = []
    for module_name in required_modules:
        try:
            importlib.import_module(module_name)
        except Exception:
            missing.append(module_name)

    if missing:
        mods = ", ".join(missing)
        raise SystemExit(
            f"Missing required modules: {mods}\n"
            "Run: pip install -r requirements.txt"
        )


def ensure_outputs(refresh: bool) -> None:
    missing_outputs = [p for p in REQUIRED_OUTPUTS if not p.exists()]
    if not refresh and not missing_outputs:
        print("Using existing model outputs.")
        return

    if refresh:
        print("Refreshing model outputs from API...")
    else:
        print("Some outputs are missing. Running pipeline now...")

    cmd = [sys.executable, str(PIPELINE_FILE)]
    completed = subprocess.run(cmd, cwd=ROOT)
    if completed.returncode != 0:
        raise SystemExit("Pipeline failed. Fix the error above and retry.")


def launch_streamlit(port: int) -> subprocess.Popen:
    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        str(APP_FILE),
        "--server.port",
        str(port),
        "--server.headless",
        "true",
        "--browser.gatherUsageStats",
        "false",
    ]
    return subprocess.Popen(cmd, cwd=ROOT)


def wait_until_ready(process: subprocess.Popen, port: int, timeout_seconds: int) -> bool:
    start = time.time()
    while time.time() - start < timeout_seconds:
        if port_is_open("127.0.0.1", port):
            return True
        if process.poll() is not None:
            return False
        time.sleep(0.4)
    return port_is_open("127.0.0.1", port)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Launch the project UI locally and open localhost."
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8501,
        help="Port for Streamlit (default: 8501).",
    )
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Always run the ML pipeline before starting the UI.",
    )
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not auto-open browser.",
    )
    parser.add_argument(
        "--attach",
        action="store_true",
        help="Keep this launcher attached to Streamlit logs (Ctrl+C to stop).",
    )
    parser.add_argument(
        "--startup-timeout",
        type=int,
        default=45,
        help="Seconds to wait for Streamlit startup (default: 45).",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if not APP_FILE.exists():
        raise SystemExit(f"App file not found: {APP_FILE}")
    if not PIPELINE_FILE.exists():
        raise SystemExit(f"Pipeline file not found: {PIPELINE_FILE}")

    check_modules()

    url = f"http://localhost:{args.port}"
    if port_is_open("127.0.0.1", args.port):
        print(f"UI already running on {url}")
        if not args.no_browser:
            webbrowser.open(url, new=2)
        return 0

    ensure_outputs(refresh=args.refresh)
    process = launch_streamlit(args.port)

    ready = wait_until_ready(process, args.port, timeout_seconds=args.startup_timeout)
    if not ready:
        if process.poll() is None:
            process.terminate()
        raise SystemExit(
            f"Streamlit did not start correctly on port {args.port}. "
            "Try a different port with --port."
        )

    print(f"UI started: {url}")
    if not args.no_browser:
        webbrowser.open(url, new=2)

    if args.attach:
        try:
            return process.wait()
        except KeyboardInterrupt:
            if process.poll() is None:
                process.terminate()
            return 0

    print("Launcher finished. Streamlit stays running in background.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
